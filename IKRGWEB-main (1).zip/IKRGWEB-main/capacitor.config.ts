import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ikrg.app',
  appName: 'Inspired Karters',
  webDir: 'out',
  server: {
    url: 'https://ikrgweb-z5tm.vercel.app',
    cleartext: false,
  },
};

export default config;
