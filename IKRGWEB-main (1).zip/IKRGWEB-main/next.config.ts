import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self' https: capacitor: http://localhost;",
              "script-src 'self' 'unsafe-inline' 'unsafe-eval' https:;",
              "style-src 'self' 'unsafe-inline' https:;",
              "connect-src 'self' https://*.supabase.co wss://*.supabase.co https:;",
              "img-src 'self' data: https:;",
              "font-src 'self' data: https: fonts.gstatic.com;",
            ].join(' '),
          },
        ],
      },
    ];
  },
};

export default nextConfig;
