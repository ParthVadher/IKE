# IKRG Operations Dashboard

An internal operations and session tracking terminal built specifically for IKRG. Features a strict 3-tier clearance level structure ensuring operation security alongside physical team metrics like Boiler Room Key tracking.

## Core Capabilities
- **Session Tracking:** Live task logs with context statuses (In Progress, Blocked, Done).
- **Clearance Level System:** Read-Only, Member, and Admin contexts with real-time UI overrides to secure actions based on L1/L2/L3 tiering.
- **Inventory Management:** Dual-state tracking linking Current Stock updates natively against Need-To-Buy priorities.
- **Boiler Key Tracking:** Fast, accountable digital transfer mappings for tracking the exact holder of the physical Boiler Room Key context.

## Stack
- **Framework:** Next.js 14 (App Router)
- **Styling:** TailwindCSS with Custom Tokens
- **Components:** Shadcn/ui
- **State Mgmt:** React Context Hook System

## Deployment & Setup
First, install the package dependencies:
```bash
npm install
```

Start the secure terminal sequence:
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) mapped to your browser interface. You can access the specific L1/L2/L3 credential configurations located securely within `src/data/users.ts`.
