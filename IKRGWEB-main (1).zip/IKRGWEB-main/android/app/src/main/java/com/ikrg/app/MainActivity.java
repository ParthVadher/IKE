package com.ikrg.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
