"use client";

export const dynamic = "force-dynamic";

import { useAuth } from "@/context/AuthContext";
import { useRole } from "@/hooks/useRole";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useState, useEffect, useCallback } from "react";
import { Plus, ExternalLink, AlertCircle, Clock } from "lucide-react";

const DOC_TYPES = ["invoice","gst_bill","mou","proposal","research_paper","meeting_minutes","fb_submission","template","other"] as const;
const SUB_STATUSES = ["draft","submitted","under_review","revision_requested","approved","rejected"] as const;

type DocType = typeof DOC_TYPES[number];
type SubStatus = typeof SUB_STATUSES[number];

type Doc = {
  id: string;
  name: string;
  type: DocType;
  related_module: string | null;
  drive_url: string;
  upload_date: string;
  remarks: string | null;
  users: { name: string } | null;
};

type Submission = {
  id: string;
  document_id: string | null;
  submitted_to: string;
  submission_date: string | null;
  deadline: string | null;
  status: SubStatus;
  reviewer_feedback: string | null;
  revision_notes: string | null;
  final_url: string | null;
  documents: { name: string } | null;
  users: { name: string } | null;
};

const SUB_STATUS_COLORS: Record<SubStatus, string> = {
  draft:             "bg-ikrg-muted/10 text-ikrg-muted border-ikrg-muted/30",
  submitted:         "bg-blue-900/20 text-blue-400 border-blue-800/30",
  under_review:      "bg-ikrg-amber/10 text-ikrg-amber border-ikrg-amber/30",
  revision_requested:"bg-orange-900/20 text-orange-400 border-orange-800/30",
  approved:          "bg-green-900/20 text-green-400 border-green-800/30",
  rejected:          "bg-ikrg-red/10 text-ikrg-red border-ikrg-red/30",
};

const DOC_TYPE_LABELS: Record<DocType, string> = {
  invoice: "Invoice", gst_bill: "GST Bill", mou: "MoU", proposal: "Proposal",
  research_paper: "Research Paper", meeting_minutes: "Meeting Minutes",
  fb_submission: "FB Submission", template: "Template", other: "Other",
};

function daysUntil(dateStr: string): number {
  return Math.ceil((new Date(dateStr).getTime() - Date.now()) / 86400000);
}

export default function DocumentsPage() {
  const { user } = useAuth();
  const canWrite = useRole("excomm", "sponsorship_team");

  const [docs, setDocs] = useState<Doc[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Doc form
  const [docOpen, setDocOpen] = useState(false);
  const [docName, setDocName] = useState("");
  const [docType, setDocType] = useState<DocType>("other");
  const [docUrl, setDocUrl] = useState("");
  const [docModule, setDocModule] = useState("");
  const [docRemarks, setDocRemarks] = useState("");
  const [docSaving, setDocSaving] = useState(false);

  // Submission form
  const [subOpen, setSubOpen] = useState(false);
  const [subTo, setSubTo] = useState("");
  const [subDeadline, setSubDeadline] = useState("");
  const [subDocId, setSubDocId] = useState("");
  const [subSaving, setSubSaving] = useState(false);

  // Edit submission status
  const [editSubOpen, setEditSubOpen] = useState(false);
  const [editSub, setEditSub] = useState<Submission | null>(null);
  const [editSubStatus, setEditSubStatus] = useState<SubStatus>("draft");
  const [editSubFeedback, setEditSubFeedback] = useState("");
  const [editSubFinalUrl, setEditSubFinalUrl] = useState("");

  const fetchAll = useCallback(async () => {
    const [{ data: d }, { data: s }] = await Promise.all([
      supabase.from("documents").select("*, users!uploaded_by(name)").order("upload_date", { ascending: false }),
      supabase.from("submissions").select("*, documents(name), users!submitted_by(name)").order("deadline", { ascending: true }),
    ]);
    if (d) setDocs(d);
    if (s) setSubmissions(s);
    setIsLoading(false);
  }, []);

  useEffect(() => { if (user) fetchAll(); }, [fetchAll, user]);

  if (!user) return null;

  const saveDoc = async () => {
    if (!docName || !docUrl) return;
    setDocSaving(true);
    await supabase.from("documents").insert({
      name: docName.trim(),
      type: docType,
      drive_url: docUrl.trim(),
      related_module: docModule.trim() || null,
      remarks: docRemarks.trim() || null,
      uploaded_by: user.id,
    });
    setDocOpen(false);
    setDocName(""); setDocUrl(""); setDocModule(""); setDocRemarks(""); setDocType("other");
    setDocSaving(false);
    fetchAll();
  };

  const saveSub = async () => {
    if (!subTo) return;
    setSubSaving(true);
    await supabase.from("submissions").insert({
      submitted_to: subTo.trim(),
      deadline: subDeadline || null,
      document_id: subDocId || null,
      submitted_by: user.id,
      status: "draft",
    });
    setSubOpen(false);
    setSubTo(""); setSubDeadline(""); setSubDocId("");
    setSubSaving(false);
    fetchAll();
  };

  const saveEditSub = async () => {
    if (!editSub) return;
    await supabase.from("submissions").update({
      status: editSubStatus,
      reviewer_feedback: editSubFeedback.trim() || null,
      final_url: editSubFinalUrl.trim() || null,
      submission_date: editSubStatus === "submitted" ? new Date().toISOString().split("T")[0] : editSub.submission_date,
      updated_by: user.id,
    }).eq("id", editSub.id);
    setEditSubOpen(false);
    fetchAll();
  };

  const openEditSub = (s: Submission) => {
    setEditSub(s);
    setEditSubStatus(s.status);
    setEditSubFeedback(s.reviewer_feedback || "");
    setEditSubFinalUrl(s.final_url || "");
    setEditSubOpen(true);
  };

  const Select = ({ label, value, onChange, children }: { label: string; value: string; onChange: (v: string) => void; children: React.ReactNode }) => (
    <div className="space-y-1.5">
      <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider font-mono">{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)}
        className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text h-8 px-2 text-xs rounded shadow-none outline-none appearance-none font-mono">
        {children}
      </select>
    </div>
  );

  return (
    <div className="p-4 flex flex-col gap-4 pb-24">
      <header className="mb-2 mt-4 flex justify-between items-end">
        <div>
          <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Repository</h1>
          <p className="text-2xl font-mono text-ikrg-text">Documents</p>
        </div>
        {canWrite && (
          <div className="flex gap-2">
            <Button size="sm" onClick={() => setSubOpen(true)} className="h-8 text-[10px] bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-text font-mono uppercase">
              Track Sub
            </Button>
            <Button size="sm" onClick={() => setDocOpen(true)} className="h-8 text-xs bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-text font-mono uppercase">
              <Plus className="w-3 h-3 mr-1" /> Doc
            </Button>
          </div>
        )}
      </header>

      <Tabs defaultValue="docs" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-ikrg-elevated border border-ikrg-border p-1 rounded-md h-9 mb-4">
          <TabsTrigger value="docs" className="data-[state=active]:bg-ikrg-card data-[state=active]:text-ikrg-text text-ikrg-muted text-[10px] font-mono rounded uppercase">Documents</TabsTrigger>
          <TabsTrigger value="submissions" className="data-[state=active]:bg-ikrg-card data-[state=active]:text-ikrg-text text-ikrg-muted text-[10px] font-mono rounded uppercase">Submissions</TabsTrigger>
        </TabsList>

        <TabsContent value="docs" className="mt-0 outline-none">
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex justify-between">
              <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">All Documents</span>
              <span className="font-mono text-[9px] text-ikrg-muted border border-ikrg-border bg-ikrg-bg px-1.5 py-0.5 rounded">{docs.length} total</span>
            </div>
            {isLoading ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse">Loading...</div>
            ) : docs.length === 0 ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No documents yet.</div>
            ) : (
              <div className="divide-y divide-ikrg-border/50">
                {docs.map(d => (
                  <div key={d.id} className="px-4 py-3 flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-mono text-sm text-ikrg-text">{d.name}</p>
                        <Badge className="text-[9px] font-mono bg-ikrg-elevated border-ikrg-border text-ikrg-text-dim">{DOC_TYPE_LABELS[d.type]}</Badge>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="font-mono text-[10px] text-ikrg-muted">{d.upload_date}</span>
                        {d.users && <span className="font-mono text-[10px] text-ikrg-muted">by {d.users.name}</span>}
                        {d.related_module && <span className="font-mono text-[10px] text-ikrg-muted capitalize">{d.related_module}</span>}
                      </div>
                      {d.remarks && <p className="text-[10px] text-ikrg-text-dim mt-0.5">{d.remarks}</p>}
                    </div>
                    <a href={d.drive_url} target="_blank" rel="noreferrer"
                      className="flex-shrink-0 text-ikrg-muted hover:text-ikrg-text transition-colors p-1">
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="submissions" className="mt-0 outline-none">
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2">
              <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">Submission Tracker</span>
            </div>
            {isLoading ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse">Loading...</div>
            ) : submissions.length === 0 ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No submissions tracked.</div>
            ) : (
              <div className="divide-y divide-ikrg-border/50">
                {submissions.map(s => {
                  const days = s.deadline ? daysUntil(s.deadline) : null;
                  const isUrgent = days !== null && days <= 7 && s.status !== "approved" && s.status !== "rejected";
                  return (
                    <div key={s.id} className={`px-4 py-3 ${isUrgent ? "bg-ikrg-red/5" : ""}`}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-mono text-sm text-ikrg-text">→ {s.submitted_to}</p>
                          {s.documents && <p className="font-mono text-[10px] text-ikrg-muted mt-0.5">{s.documents.name}</p>}
                          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                            {s.deadline && (
                              <span className={`font-mono text-[10px] flex items-center gap-0.5 ${isUrgent ? "text-ikrg-red" : "text-ikrg-muted"}`}>
                                <Clock className="w-2.5 h-2.5" />
                                {days !== null && days >= 0 ? `${days}d left` : "OVERDUE"} ({s.deadline})
                              </span>
                            )}
                          </div>
                          {s.reviewer_feedback && (
                            <p className="text-[10px] text-ikrg-amber mt-1 italic">"{s.reviewer_feedback}"</p>
                          )}
                        </div>
                        <div className="flex flex-col items-end gap-1.5">
                          <Badge className={`text-[9px] font-mono border ${SUB_STATUS_COLORS[s.status]}`}>
                            {s.status.replace("_", " ")}
                          </Badge>
                          {s.final_url && (
                            <a href={s.final_url} target="_blank" rel="noreferrer" className="text-[9px] text-blue-400 hover:underline font-mono">Final →</a>
                          )}
                          {canWrite && (
                            <button onClick={() => openEditSub(s)} className="font-mono text-[9px] text-ikrg-muted hover:text-ikrg-text uppercase">Edit →</button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Add Document Dialog */}
      <Dialog open={docOpen} onOpenChange={setDocOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Add Document</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Name *</label>
              <Input value={docName} onChange={e => setDocName(e.target.value)} placeholder="Document name"
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
            <Select label="Type" value={docType} onChange={v => setDocType(v as DocType)}>
              {DOC_TYPES.map(t => <option key={t} value={t}>{DOC_TYPE_LABELS[t]}</option>)}
            </Select>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Google Drive URL *</label>
              <Input value={docUrl} onChange={e => setDocUrl(e.target.value)} placeholder="https://drive.google.com/..."
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Related Module</label>
              <Input value={docModule} onChange={e => setDocModule(e.target.value)} placeholder="e.g. sponsor, transaction"
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Remarks</label>
              <Input value={docRemarks} onChange={e => setDocRemarks(e.target.value)}
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setDocOpen(false)}>Cancel</Button>
            <Button disabled={!docName || !docUrl || docSaving} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={saveDoc}>
              {docSaving ? "Saving..." : "Add Document"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Track Submission Dialog */}
      <Dialog open={subOpen} onOpenChange={setSubOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Track Submission</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Submitted To *</label>
              <Input value={subTo} onChange={e => setSubTo(e.target.value)} placeholder="e.g. Formula Bharat, Dean"
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Deadline</label>
              <Input type="date" value={subDeadline} onChange={e => setSubDeadline(e.target.value)}
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
            <Select label="Linked Document" value={subDocId} onChange={setSubDocId}>
              <option value="">None</option>
              {docs.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setSubOpen(false)}>Cancel</Button>
            <Button disabled={!subTo || subSaving} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={saveSub}>
              {subSaving ? "Saving..." : "Track"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Submission Status */}
      <Dialog open={editSubOpen} onOpenChange={setEditSubOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Update Submission</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            {editSub && <p className="text-xs text-ikrg-text-dim">→ {editSub.submitted_to}</p>}
            <Select label="Status" value={editSubStatus} onChange={v => setEditSubStatus(v as SubStatus)}>
              {SUB_STATUSES.map(s => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
            </Select>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Reviewer Feedback</label>
              <Input value={editSubFeedback} onChange={e => setEditSubFeedback(e.target.value)}
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Final Version URL</label>
              <Input value={editSubFinalUrl} onChange={e => setEditSubFinalUrl(e.target.value)} placeholder="https://drive.google.com/..."
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setEditSubOpen(false)}>Cancel</Button>
            <Button className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={saveEditSub}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
