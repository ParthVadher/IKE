"use client";

export const dynamic = "force-dynamic";

import { useAuth } from "@/context/AuthContext";
import { useRole } from "@/hooks/useRole";
import { supabase } from "@/lib/supabase";
import { useState, useEffect, useCallback } from "react";
import { Bell, Check, CheckCheck, Megaphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

type Notification = {
  id: string;
  type: string;
  title: string;
  body: string | null;
  related_module: string | null;
  is_read: boolean;
  created_at: string;
};

type Role = { id: string; label: string };

const TYPE_COLORS: Record<string, string> = {
  finance:       "text-ikrg-green",
  sponsor:       "text-ikrg-amber",
  inventory:     "text-blue-400",
  documentation: "text-purple-400",
  general:       "text-ikrg-text-dim",
  announcement:  "text-ikrg-red",
};

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export default function NotificationsPage() {
  const { user } = useAuth();
  const isExcomm = useRole("excomm");
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [roles, setRoles] = useState<Role[]>([]);

  const [composeOpen, setComposeOpen] = useState(false);
  const [composeTitle, setComposeTitle] = useState("");
  const [composeBody, setComposeBody] = useState("");
  const [audience, setAudience] = useState<"all" | "roles">("all");
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState("");

  const fetchNotifications = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    if (data) setNotifications(data);
    setIsLoading(false);
  }, [user]);

  useEffect(() => { fetchNotifications(); }, [fetchNotifications]);

  useEffect(() => {
    if (!user) return;
    supabase.from("roles").select("id, label").order("sort_order").then(({ data }) => { if (data) setRoles(data); });
  }, [user]);

  const toggleRole = (roleId: string) => {
    setSelectedRoles(prev => prev.includes(roleId) ? prev.filter(r => r !== roleId) : [...prev, roleId]);
  };

  if (!user) return null;

  const markRead = async (id: string) => {
    await supabase.from("notifications").update({ is_read: true }).eq("id", id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
  };

  const markAllRead = async () => {
    const unread = notifications.filter(n => !n.is_read);
    await Promise.all(unread.map(n => supabase.from("notifications").update({ is_read: true }).eq("id", n.id)));
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  const sendBroadcast = async () => {
    if (!composeTitle.trim()) return;
    if (audience === "roles" && selectedRoles.length === 0) return;
    setSending(true);
    setSendError("");
    const roleIds = audience === "roles" ? selectedRoles : null;
    const { error } = await supabase.rpc("broadcast_notification", {
      p_title: composeTitle.trim(),
      p_body: composeBody.trim() || null,
      p_type: "announcement",
      p_role_ids: roleIds,
    });
    if (error) { setSending(false); setSendError(error.message); return; }

    // Best-effort: also push to devices. In-app notification above already succeeded
    // regardless of whether this push step works (e.g. FCM secret not configured yet).
    await supabase.functions.invoke("send-push", {
      body: { title: composeTitle.trim(), body: composeBody.trim() || undefined, role_ids: roleIds },
    }).catch(() => {});

    setSending(false);
    setComposeOpen(false);
    setComposeTitle(""); setComposeBody(""); setAudience("all"); setSelectedRoles([]);
    fetchNotifications();
  };

  return (
    <div className="p-4 flex flex-col gap-4 pb-24">
      <header className="mb-2 mt-4 flex justify-between items-end">
        <div>
          <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Alerts</h1>
          <p className="text-2xl font-mono text-ikrg-text">Notifications</p>
        </div>
        <div className="flex items-center gap-2">
          {isExcomm && (
            <Button size="sm" onClick={() => setComposeOpen(true)} className="h-8 text-[10px] bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-text font-mono uppercase">
              <Megaphone className="w-3 h-3 mr-1" /> Announce
            </Button>
          )}
          {unreadCount > 0 && (
            <Button size="sm" onClick={markAllRead} className="h-8 text-[10px] bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-text font-mono uppercase">
              <CheckCheck className="w-3 h-3 mr-1" /> Mark All Read
            </Button>
          )}
        </div>
      </header>

      {unreadCount > 0 && (
        <div className="bg-ikrg-red/10 border border-ikrg-red/30 rounded px-3 py-2">
          <p className="font-mono text-[10px] text-ikrg-red uppercase tracking-widest">{unreadCount} unread notification{unreadCount !== 1 ? "s" : ""}</p>
        </div>
      )}

      <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
        {isLoading ? (
          <div className="py-16 text-center font-mono text-xs text-ikrg-muted animate-pulse uppercase tracking-widest">Loading...</div>
        ) : notifications.length === 0 ? (
          <div className="py-16 text-center flex flex-col items-center gap-3">
            <Bell className="w-8 h-8 text-ikrg-border" />
            <p className="font-mono text-xs text-ikrg-muted">No notifications yet.</p>
          </div>
        ) : (
          <div className="divide-y divide-ikrg-border/50">
            {notifications.map(n => (
              <div key={n.id} className={`px-4 py-3 flex items-start gap-3 transition-colors ${n.is_read ? "opacity-50" : "bg-ikrg-elevated/30"}`}>
                <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${n.is_read ? "bg-ikrg-border" : "bg-ikrg-red animate-pulse"}`} />
                <div className="flex-1 min-w-0">
                  <p className="font-mono text-sm text-ikrg-text">{n.title}</p>
                  {n.body && <p className="text-[11px] text-ikrg-text-dim mt-0.5 leading-snug">{n.body}</p>}
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`font-mono text-[9px] uppercase ${TYPE_COLORS[n.type] ?? "text-ikrg-muted"}`}>{n.type}</span>
                    <span className="font-mono text-[9px] text-ikrg-muted">{timeAgo(n.created_at)}</span>
                  </div>
                </div>
                {!n.is_read && (
                  <button onClick={() => markRead(n.id)} className="text-ikrg-muted hover:text-ikrg-green transition-colors p-1 flex-shrink-0">
                    <Check className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {isExcomm && (
        <Dialog open={composeOpen} onOpenChange={o => { setComposeOpen(o); if (!o) setSendError(""); }}>
          <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
            <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">New Announcement</DialogTitle></DialogHeader>
            <div className="flex flex-col gap-3 mt-2">
              <div className="space-y-1.5">
                <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Title *</label>
                <Input value={composeTitle} onChange={e => setComposeTitle(e.target.value)} placeholder="Ex: General Meeting Tonight"
                  className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Message</label>
                <textarea value={composeBody} onChange={e => setComposeBody(e.target.value)} placeholder="Optional details..."
                  className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text text-xs p-2 rounded shadow-none outline-none min-h-[70px] resize-none font-sans" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Send To</label>
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => setAudience("all")}
                    className={`h-8 text-[10px] rounded border font-mono uppercase transition-colors ${audience === "all" ? "bg-ikrg-red border-ikrg-red text-white" : "bg-ikrg-bg border-ikrg-border text-ikrg-muted"}`}>
                    Everyone
                  </button>
                  <button type="button" onClick={() => setAudience("roles")}
                    className={`h-8 text-[10px] rounded border font-mono uppercase transition-colors ${audience === "roles" ? "bg-ikrg-red border-ikrg-red text-white" : "bg-ikrg-bg border-ikrg-border text-ikrg-muted"}`}>
                    Specific Roles
                  </button>
                </div>
                {audience === "roles" && (
                  <div className="grid grid-cols-2 gap-1.5 mt-1.5">
                    {roles.map(r => (
                      <label key={r.id} onClick={() => toggleRole(r.id)} className="flex items-center gap-2 text-[11px] text-ikrg-muted hover:text-ikrg-text cursor-pointer">
                        <div className={`w-3 h-3 rounded-sm border flex items-center justify-center flex-shrink-0 transition-colors ${selectedRoles.includes(r.id) ? "bg-ikrg-red border-ikrg-red" : "border-ikrg-border bg-ikrg-bg"}`}>
                          {selectedRoles.includes(r.id) && <div className="w-1.5 h-1.5 bg-ikrg-bg rounded-sm" />}
                        </div>
                        {r.label}
                      </label>
                    ))}
                  </div>
                )}
              </div>
              {sendError && <p className="text-[10px] text-ikrg-red font-mono">{sendError}</p>}
            </div>
            <DialogFooter className="mt-4 flex sm:justify-start gap-2">
              <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setComposeOpen(false)}>Cancel</Button>
              <Button disabled={!composeTitle.trim() || sending || (audience === "roles" && selectedRoles.length === 0)} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={sendBroadcast}>
                {sending ? "Sending..." : "Send"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
