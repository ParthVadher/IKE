"use client";

import { useAuth, User as AuthUser } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { LogOut, User as UserIcon, Shield, Plus, Trash2 } from "lucide-react";
import { usePermission } from "@/hooks/usePermission";
import { useRole } from "@/hooks/useRole";
import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

type UserWithRoles = AuthUser & { roleIds: string[] };

const ALL_ROLES = [
  { id: "excomm",           label: "ExComm" },
  { id: "sponsorship_team", label: "Management" },
  { id: "subsystem_lead",   label: "Subsystem Lead" },
  { id: "general_member",   label: "General Member" },
  { id: "alumni",           label: "Alumni" },
  { id: "mentors",          label: "Mentors" },
];

function roleBadgeClass(roleId: string): string {
  if (roleId === "excomm") return "bg-ikrg-red/10 text-ikrg-red border-ikrg-red/30";
  if (roleId === "sponsorship_team") return "bg-ikrg-amber/10 text-ikrg-amber border-ikrg-amber/30";
  if (roleId === "subsystem_lead") return "bg-green-900/20 text-green-400 border-green-800/30";
  if (roleId === "alumni") return "bg-blue-900/20 text-blue-400 border-blue-800/30";
  if (roleId === "mentors") return "bg-purple-900/20 text-purple-400 border-purple-800/30";
  return "bg-ikrg-elevated text-ikrg-text-dim border-ikrg-border";
}

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const isAdmin = usePermission(3);
  const isSuperAdmin = usePermission(4);
  const isExcomm = useRole("excomm");
  const isAlumni = user?.subsystem === "Alumni" || user?.roles.includes("alumni");

  const [allUsers, setAllUsers] = useState<UserWithRoles[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<UserWithRoles | null>(null);
  const [deleteStep, setDeleteStep] = useState(0);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newLevel, setNewLevel] = useState(2);
  const [newSubsystem, setNewSubsystem] = useState("");
  const [newRoles, setNewRoles] = useState<string[]>(["general_member"]);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"all" | "25" | "24" | "23" | "22">("all");
  const [roleEditTarget, setRoleEditTarget] = useState<UserWithRoles | null>(null);
  const [pendingRoles, setPendingRoles] = useState<string[]>([]);
  const [isSavingRoles, setIsSavingRoles] = useState(false);

  const filteredUsers = allUsers.filter(u => {
    if (activeTab === "all") return true;
    const email = u.email.toLowerCase();
    if (activeTab === "25" && email.startsWith("f2025")) return true;
    if (activeTab === "24" && email.startsWith("f2024")) return true;
    if (activeTab === "23" && email.startsWith("f2023")) return true;
    if (activeTab === "22" && email.startsWith("f2022")) return true;
    return false;
  });

  const fetchUsers = useCallback(async () => {
    if (!isAdmin && !isAlumni) return;
    const { data: userRows } = await supabase.from("users").select("*").order("name");
    const { data: roleRows } = await supabase.from("user_roles").select("user_id, role_id");
    if (!userRows) return;

    const roleMap: Record<string, string[]> = {};
    for (const r of roleRows ?? []) {
      if (!roleMap[r.user_id]) roleMap[r.user_id] = [];
      roleMap[r.user_id].push(r.role_id);
    }

    setAllUsers(userRows.map((u: any) => ({
      id: u.id,
      auth_id: u.auth_id,
      name: u.name,
      username: u.username,
      email: u.email,
      subsystem: u.subsystem,
      clearanceLevel: u.clearance_level,
      roles: roleMap[u.id] ?? [],
      roleIds: roleMap[u.id] ?? [],
    })));
  }, [isAdmin, isAlumni]);

  useEffect(() => { if (user) fetchUsers(); }, [fetchUsers, user]);

  if (!user) return null;

  const handleAddMember = async () => {
    setError("");
    const sanitizedEmail = newEmail.trim().toLowerCase();
    const sanitizedName = newName.trim();

    if (!sanitizedEmail.endsWith("@pilani.bits-pilani.ac.in") && !sanitizedEmail.endsWith("@alumni.bits-pilani.ac.in")) {
      setError("Only @pilani or @alumni.bits-pilani.ac.in emails are permitted");
      return;
    }

    setIsLoading(true);
    try {
      const { data: inserted, error: dbError } = await supabase.from("users").insert({
        name: sanitizedName,
        email: sanitizedEmail,
        username: sanitizedEmail.split("@")[0],
        clearance_level: newLevel,
        subsystem: newSubsystem.trim() || "—"
      }).select("id").single();

      if (dbError) throw new Error(dbError.message || "Database rejection.");

      // Assign roles
      if (inserted && newRoles.length > 0) {
        await supabase.from("user_roles").insert(
          newRoles.map(r => ({ user_id: inserted.id, role_id: r }))
        );
      }

      setIsAddOpen(false);
      setNewName(""); setNewEmail(""); setNewLevel(2); setNewSubsystem(""); setNewRoles(["general_member"]);
      fetchUsers();
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemoveMember = async (targetUserId: string) => {
    setIsLoading(true);
    try {
      const { error: dbError } = await supabase.from("users").delete().eq("id", targetUserId);
      if (dbError) throw dbError;
      fetchUsers();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleChangeLevel = async (targetId: string, level: number) => {
    await supabase.from("users").update({ clearance_level: level }).eq("id", targetId);
    fetchUsers();
  };

  const openRoleEditor = (u: UserWithRoles) => {
    setRoleEditTarget(u);
    setPendingRoles([...u.roleIds]);
  };

  const handleSaveRoles = async () => {
    if (!roleEditTarget) return;
    setIsSavingRoles(true);
    try {
      // Delete all current roles for this user, re-insert selected
      await supabase.from("user_roles").delete().eq("user_id", roleEditTarget.id);
      if (pendingRoles.length > 0) {
        await supabase.from("user_roles").insert(
          pendingRoles.map(r => ({ user_id: roleEditTarget.id, role_id: r }))
        );
      }
      // Mirror clearance_level: excomm→4, subsystem_lead→3, mentors→1 (view-only, below the edit threshold), else→2
      const newLevel = pendingRoles.includes("excomm") ? 4
        : pendingRoles.includes("subsystem_lead") ? 3
        : pendingRoles.includes("mentors") ? 1 : 2;
      await supabase.from("users").update({ clearance_level: newLevel }).eq("id", roleEditTarget.id);

      setRoleEditTarget(null);
      fetchUsers();
    } finally {
      setIsSavingRoles(false);
    }
  };

  const togglePendingRole = (roleId: string) => {
    setPendingRoles(prev =>
      prev.includes(roleId) ? prev.filter(r => r !== roleId) : [...prev, roleId]
    );
  };

  return (
    <div className="p-4 flex flex-col gap-6 pb-24">
      <header className="mb-2 mt-4 flex justify-between items-end">
        <div>
          <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Identity</h1>
          <p className="text-2xl font-mono text-ikrg-text">Profile</p>
        </div>
        <Button onClick={logout} size="sm" variant="ghost" className="text-ikrg-red font-mono text-[10px] uppercase">
          <LogOut className="w-3 h-3 mr-1" /> Log off
        </Button>
      </header>

      {/* Identity card */}
      <div className="bg-ikrg-card border border-ikrg-border rounded-lg p-6 flex flex-col items-center justify-center text-center mt-4">
        <div className="w-20 h-20 bg-ikrg-elevated rounded-full flex items-center justify-center mb-4 border border-ikrg-border text-ikrg-text-dim relative">
          <UserIcon size={32} />
          <div className="absolute -bottom-1 -right-1 bg-ikrg-red text-white text-[10px] font-bold px-1.5 py-0.5 rounded border border-ikrg-bg">
            L{user.clearanceLevel}
          </div>
        </div>
        <h2 className="text-xl font-mono text-ikrg-text">{user.name}</h2>
        <p className="font-mono text-sm text-ikrg-red uppercase tracking-widest mt-1">{user.subsystem}</p>

        {user.roles.length > 0 && (
          <div className="flex flex-wrap gap-1.5 justify-center mt-3">
            {user.roles.map(r => {
              const role = ALL_ROLES.find(x => x.id === r);
              return role ? (
                <Badge key={r} className={`text-[9px] font-mono border ${roleBadgeClass(r)}`}>{role.label}</Badge>
              ) : null;
            })}
          </div>
        )}

        <div className="w-full h-px bg-ikrg-border my-6" />

        <div className="w-full text-left flex flex-col gap-3 font-mono text-xs">
          <div className="flex justify-between items-center">
            <span className="text-ikrg-text-dim uppercase text-[10px]">Email</span>
            <span className="text-ikrg-text">{user.email}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-ikrg-text-dim uppercase text-[10px]">Access Level</span>
            <span className="text-ikrg-text">Clearance {user.clearanceLevel}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-ikrg-text-dim uppercase text-[10px]">Status</span>
            <Badge className="bg-ikrg-green/10 text-ikrg-green border-ikrg-green/30 text-[9px] font-mono">GOOGLE AUTH // SECURE</Badge>
          </div>
        </div>
      </div>

      {/* Team directory / manage allowlist */}
      {(isAdmin || isAlumni) && (
        <section className="animate-in fade-in slide-in-from-bottom-2 duration-500">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-ikrg-amber" />
              <h2 className="font-mono text-sm text-ikrg-amber uppercase tracking-widest">
                {isAlumni && !isAdmin ? "Team Members" : "Manage Allowlist"}
              </h2>
            </div>
            {isAdmin && (
              <Button size="sm" onClick={() => setIsAddOpen(true)} className="h-7 text-[10px] bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-text font-mono uppercase">
                <Plus className="w-3 h-3 mr-1" /> Add Email
              </Button>
            )}
          </div>

          <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
            {(["all", "25", "24", "23", "22"] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1.5 text-[10px] font-mono uppercase rounded transition-colors whitespace-nowrap ${
                  activeTab === tab
                    ? "bg-ikrg-border text-ikrg-text border border-ikrg-text/20 shadow-sm"
                    : "bg-ikrg-elevated text-ikrg-text-dim border border-ikrg-border hover:bg-ikrg-border/50"
                }`}
              >
                {tab === "all" ? "All Members" : `Batch '${tab}`}
              </button>
            ))}
          </div>

          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full font-mono text-[11px] text-left">
                <thead className="bg-ikrg-elevated border-b border-ikrg-border uppercase text-ikrg-text-dim">
                  <tr>
                    <th className="px-3 py-2 font-medium">Member</th>
                    <th className="px-3 py-2 font-medium">Roles</th>
                    {isAdmin && <th className="px-3 py-2 font-medium text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-ikrg-border">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={isAdmin ? 3 : 2} className="px-3 py-6 text-center text-ikrg-muted italic">
                        No members found in this category.
                      </td>
                    </tr>
                  ) : filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="px-3 py-3">
                        <div className="flex flex-col">
                          <span className="text-ikrg-text font-medium">{u.name}</span>
                          <span className="text-[10px] text-ikrg-muted -mt-0.5">{u.email}</span>
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex flex-wrap gap-1">
                          {u.roleIds.length === 0 ? (
                            <span className="text-ikrg-muted text-[10px]">—</span>
                          ) : u.roleIds.map(r => {
                            const role = ALL_ROLES.find(x => x.id === r);
                            return role ? (
                              <Badge key={r} className={`text-[9px] font-mono border ${roleBadgeClass(r)}`}>{role.label}</Badge>
                            ) : null;
                          })}
                        </div>
                      </td>
                      {isAdmin && (
                        <td className="px-3 py-3 text-right">
                          <div className="flex gap-1 justify-end">
                            {isExcomm && u.clearanceLevel < 4 && (
                              <button
                                onClick={() => openRoleEditor(u)}
                                className="text-ikrg-amber hover:bg-ikrg-amber/10 p-1 rounded transition-colors text-[10px] font-mono uppercase"
                                title="Edit roles"
                              >
                                <Shield size={13} />
                              </button>
                            )}
                            {isSuperAdmin && u.email !== user.email && u.clearanceLevel !== 4 && (
                              <button
                                onClick={() => { setDeleteTarget(u); setDeleteStep(1); }}
                                disabled={isLoading}
                                className="text-ikrg-red hover:bg-ikrg-red/10 p-1 rounded transition-colors disabled:opacity-50"
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      {/* Role editor dialog */}
      <Dialog open={!!roleEditTarget} onOpenChange={(open) => !open && setRoleEditTarget(null)}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="text-ikrg-text font-mono text-sm tracking-widest uppercase">
              Edit Roles — {roleEditTarget?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            {ALL_ROLES.map(role => (
              <label key={role.id} className="flex items-center gap-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={pendingRoles.includes(role.id)}
                  onChange={() => togglePendingRole(role.id)}
                  className="accent-ikrg-red w-4 h-4 rounded"
                />
                <Badge className={`text-[9px] font-mono border ${roleBadgeClass(role.id)}`}>{role.label}</Badge>
              </label>
            ))}
          </div>
          <p className="text-[10px] text-ikrg-muted mt-2">Clearance level will be synced automatically.</p>
          <DialogFooter className="flex flex-col-reverse sm:flex-row gap-2 sm:justify-end mt-4">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-9 rounded text-xs"
              onClick={() => setRoleEditTarget(null)}>
              Cancel
            </Button>
            <Button disabled={isSavingRoles} className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-9 rounded text-xs"
              onClick={handleSaveRoles}>
              {isSavingRoles ? "Saving..." : "Save Roles"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation dialog */}
      <Dialog open={deleteStep > 0} onOpenChange={(open) => !open && setDeleteStep(0)}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-red/50 font-mono text-center">
          <DialogHeader>
            <DialogTitle className="text-ikrg-red font-mono text-sm tracking-widest uppercase">
              {deleteStep === 1 && "Hold up!"}
              {deleteStep === 2 && "Seriously?"}
              {deleteStep === 3 && "Final Warning"}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4 text-xs text-ikrg-text">
            {deleteStep === 1 && <p>Are you absolutely sure you want to delete <span className="font-bold text-ikrg-red">{deleteTarget?.name}</span>? They will be banished to the digital shadow realm!</p>}
            {deleteStep === 2 && <p>Like, really really sure? This isn't a drill. <span className="font-bold text-ikrg-red">{deleteTarget?.name}</span> will lose all access immediately.</p>}
            {deleteStep === 3 && <p>Last chance to back out! If they complain about being locked out, that's entirely on you. Terminate?</p>}
          </div>
          <DialogFooter className="flex flex-col-reverse sm:flex-row gap-2 sm:justify-center">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-9 rounded text-xs"
              onClick={() => setDeleteStep(0)}>Nevermind</Button>
            <Button disabled={isLoading} className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-9 rounded text-xs transition-all active:scale-95"
              onClick={async () => {
                if (deleteStep < 3) { setDeleteStep(deleteStep + 1); }
                else if (deleteTarget) { await handleRemoveMember(deleteTarget.id); setDeleteStep(0); }
              }}>
              {isLoading ? "Deleting..." : deleteStep === 3 ? "Yes, Terminate!" : "I know what I'm doing"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add member dialog */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="text-ikrg-text font-mono text-sm tracking-widest uppercase">Add Terminal Member</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-2">
            <div className="p-2 border border-ikrg-amber/30 bg-ikrg-amber/5 rounded">
              <p className="text-[10px] text-ikrg-amber uppercase flex items-center gap-1.5">
                <Shield size={12} /> Access Protocol
              </p>
              <p className="text-[10px] text-ikrg-amber/80 mt-1">
                New member must have a valid BITS Pilani email. Their account will be authorized on their first Google login.
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Full Name</label>
              <Input value={newName} onChange={e => setNewName(e.target.value)} placeholder="Ex: Aryan Rao"
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">BITS Email</label>
              <Input value={newEmail} onChange={e => setNewEmail(e.target.value)} placeholder="id@pilani.bits-pilani.ac.in"
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Subsystem</label>
              <Input value={newSubsystem} onChange={e => setNewSubsystem(e.target.value)} placeholder="Ex: Mechanical"
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Roles</label>
              <div className="flex flex-col gap-2 p-2 bg-ikrg-bg border border-ikrg-border rounded">
                {ALL_ROLES.map(role => (
                  <label key={role.id} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={newRoles.includes(role.id)}
                      onChange={() => setNewRoles(prev => prev.includes(role.id) ? prev.filter(r => r !== role.id) : [...prev, role.id])}
                      className="accent-ikrg-red w-3.5 h-3.5" />
                    <span className="text-[10px] text-ikrg-text">{role.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {error && <p className="text-ikrg-red text-[10px] font-mono animate-in fade-in slide-in-from-top-1">{error}</p>}
          </div>
          <div className="mt-6 flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pr-1">
            <Button type="button" variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-9 rounded text-xs px-4"
              onClick={() => setIsAddOpen(false)}>Cancel</Button>
            <Button type="button" disabled={!newName || !newEmail || isLoading}
              className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-9 rounded text-xs px-4 min-w-[120px] transition-all active:scale-95"
              onClick={handleAddMember}>
              {isLoading ? "Updating..." : "Update Allowlist"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
