"use client";

export const dynamic = "force-dynamic";

import { useAuth } from "@/context/AuthContext";
import { useRole } from "@/hooks/useRole";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useEffect, useCallback } from "react";
import { Settings as SettingsIcon, Plus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

type Settings = {
  opening_bank: number;
  opening_dean: number;
  opening_bitsaa: number;
  financial_year: string;
};

type Category = { id: string; name: string; type: string };
type Department = { id: string; name: string };

export default function SettingsPage() {
  const { user } = useAuth();
  const isExcomm = useRole("excomm");
  const isMentor = useRole("mentors");

  const [settings, setSettings] = useState<Settings>({ opening_bank: 0, opening_dean: 0, opening_bitsaa: 0, financial_year: "2025-26" });
  const [categories, setCategories] = useState<Category[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [newCat, setNewCat] = useState("");
  const [newDept, setNewDept] = useState("");
  const [addCatOpen, setAddCatOpen] = useState(false);
  const [addDeptOpen, setAddDeptOpen] = useState(false);

  const fetchAll = useCallback(async () => {
    const [{ data: s }, { data: cats }, { data: depts }] = await Promise.all([
      supabase.from("settings").select("*").single(),
      supabase.from("categories").select("*").order("name"),
      supabase.from("departments").select("*").order("name"),
    ]);
    if (s) setSettings(s);
    if (cats) setCategories(cats);
    if (depts) setDepartments(depts);
  }, []);

  useEffect(() => { if (user) fetchAll(); }, [fetchAll, user]);

  if (!user) return null;
  if (!isExcomm && !isMentor) return (
    <div className="p-6 pt-16 text-center font-mono text-xs text-ikrg-muted uppercase tracking-widest">
      ExComm Access Only
    </div>
  );

  const saveSettings = async () => {
    setIsSaving(true);
    await supabase.from("settings").update({
      opening_bank: settings.opening_bank,
      opening_dean: settings.opening_dean,
      opening_bitsaa: settings.opening_bitsaa,
      financial_year: settings.financial_year,
      updated_by: user.id,
    }).eq("id", "singleton");
    setIsSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const addCategory = async () => {
    if (!newCat.trim()) return;
    await supabase.from("categories").insert({ name: newCat.trim(), type: "finance" });
    setNewCat("");
    setAddCatOpen(false);
    fetchAll();
  };

  const addDepartment = async () => {
    if (!newDept.trim()) return;
    await supabase.from("departments").insert({ name: newDept.trim() });
    setNewDept("");
    setAddDeptOpen(false);
    fetchAll();
  };

  const Field = ({ label, value, onChange, type = "text" }: { label: string; value: string | number; onChange: (v: string) => void; type?: string }) => (
    <div className="space-y-1.5">
      <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider font-mono">{label}</label>
      <Input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none font-mono"
      />
    </div>
  );

  return (
    <div className="p-4 flex flex-col gap-6 pb-24">
      <header className="mb-2 mt-4 flex items-center gap-3">
        <SettingsIcon className="w-5 h-5 text-ikrg-muted" />
        <div>
          <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest">ExComm</h1>
          <p className="text-2xl font-mono text-ikrg-text">Settings</p>
        </div>
      </header>

      {/* Financial config (ExComm only — finances are excomm-restricted) */}
      {isExcomm && (
        <section className="bg-ikrg-card border border-ikrg-border rounded-lg p-4 flex flex-col gap-4">
          <h2 className="font-mono text-xs text-ikrg-amber uppercase tracking-widest">Financial Year</h2>
          <Field label="Financial Year" value={settings.financial_year} onChange={v => setSettings(s => ({ ...s, financial_year: v }))} />
          <h2 className="font-mono text-xs text-ikrg-amber uppercase tracking-widest mt-2">Opening Balances (₹)</h2>
          <Field label="Bank" type="number" value={settings.opening_bank} onChange={v => setSettings(s => ({ ...s, opening_bank: parseFloat(v) || 0 }))} />
          <Field label="Dean's Fund" type="number" value={settings.opening_dean} onChange={v => setSettings(s => ({ ...s, opening_dean: parseFloat(v) || 0 }))} />
          <Field label="BITSAA" type="number" value={settings.opening_bitsaa} onChange={v => setSettings(s => ({ ...s, opening_bitsaa: parseFloat(v) || 0 }))} />
          <Button onClick={saveSettings} disabled={isSaving} className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-8 rounded text-xs mt-1">
            {isSaving ? "Saving..." : saved ? "Saved!" : "Save Changes"}
          </Button>
        </section>
      )}

      {/* Categories */}
      <section className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 bg-ikrg-elevated border-b border-ikrg-border">
          <h2 className="font-mono text-xs text-ikrg-text-dim uppercase tracking-widest">Categories</h2>
          {isExcomm && (
            <button onClick={() => setAddCatOpen(true)} className="text-ikrg-muted hover:text-ikrg-text transition-colors">
              <Plus className="w-4 h-4" />
            </button>
          )}
        </div>
        <p className="px-4 pt-3 text-[10px] text-ikrg-text-dim leading-relaxed">
          What the money was spent on: tagged on every transaction regardless of which department bought it.
        </p>
        <div className="divide-y divide-ikrg-border mt-1">
          {categories.map(cat => (
            <div key={cat.id} className="px-4 py-2.5">
              <span className="font-mono text-xs text-ikrg-text">{cat.name}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Departments */}
      <section className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 bg-ikrg-elevated border-b border-ikrg-border">
          <h2 className="font-mono text-xs text-ikrg-text-dim uppercase tracking-widest">Departments</h2>
          {isExcomm && (
            <button onClick={() => setAddDeptOpen(true)} className="text-ikrg-muted hover:text-ikrg-text transition-colors">
              <Plus className="w-4 h-4" />
            </button>
          )}
        </div>
        <p className="px-4 pt-3 text-[10px] text-ikrg-text-dim leading-relaxed">
          Who spent the money: which team's budget every transaction is tagged against (e.g. "Electrical spent ₹X this year").
        </p>
        <div className="divide-y divide-ikrg-border mt-1">
          {departments.map(dept => (
            <div key={dept.id} className="px-4 py-2.5">
              <span className="font-mono text-xs text-ikrg-text">{dept.name}</span>
            </div>
          ))}
        </div>
      </section>

      <Dialog open={addCatOpen} onOpenChange={setAddCatOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Add Category</DialogTitle></DialogHeader>
          <Input value={newCat} onChange={e => setNewCat(e.target.value)} placeholder="Category name"
            className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none mt-2" />
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setAddCatOpen(false)}>Cancel</Button>
            <Button disabled={!newCat.trim()} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={addCategory}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={addDeptOpen} onOpenChange={setAddDeptOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Add Department</DialogTitle></DialogHeader>
          <Input value={newDept} onChange={e => setNewDept(e.target.value)} placeholder="Department name"
            className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none mt-2" />
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setAddDeptOpen(false)}>Cancel</Button>
            <Button disabled={!newDept.trim()} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={addDepartment}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
