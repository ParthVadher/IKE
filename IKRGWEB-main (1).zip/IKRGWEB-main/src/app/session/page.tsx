"use client";

export const dynamic = "force-dynamic";


import { useAuth } from "@/context/AuthContext";
import { SessionTaskRow } from "@/components/SessionTaskRow";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus } from "lucide-react";
import { usePermission } from "@/hooks/usePermission";
import { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { supabase } from "@/lib/supabase";
import { useSubsystems } from "@/context/SubsystemContext";

export type Task = {
  id: string;
  userId: string;
  title: string;
  status: "In Progress" | "Done" | "Blocked";
  subsystemsAffected: string[];
};

export default function SessionPage() {
  const { user } = useAuth();
  const canEdit = usePermission(2);
  
  const [localTasks, setLocalTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [taskName, setTaskName] = useState("");
  const [status, setStatus] = useState<"In Progress" | "Blocked">("In Progress");
  const [notes, setNotes] = useState("");
  const { subsystems: allSubsystems } = useSubsystems();
  const [subsystems, setSubsystems] = useState<string[]>([]);

  const fetchData = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("tasks")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (data && !error) {
      const formatted: Task[] = data.map((t: any) => ({
        id: t.id,
        userId: user.username, // keep username for UI consistency if used in children
        title: t.title,
        status: t.status === "in_progress" ? "In Progress" : (t.status === "done" ? "Done" : "Blocked"),
        subsystemsAffected: t.affected_subsystems || [],
      }));
      setLocalTasks(formatted);
    }
    setIsLoading(false);
  }, [user]);

  useEffect(() => {
    fetchData();

    if (!user) return;
    const channel = supabase
      .channel("task_changes")
      .on("postgres_changes", 
        { event: "*", schema: "public", table: "tasks", filter: `user_id=eq.${user.id}` }, 
        () => fetchData()
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [fetchData, user]);

  if (!user) return null;

  const doneCount = localTasks.filter(t => t.status === "Done").length;
  const progressCount = localTasks.filter(t => t.status === "In Progress").length;
  const blockedCount = localTasks.filter(t => t.status === "Blocked").length;

  const toggleSubsystem = (ss: string) => {
    setSubsystems(prev => 
      prev.includes(ss) ? prev.filter(s => s !== ss) : [...prev, ss]
    );
  };

  const submitTask = async () => {
    if (!taskName.trim()) return;

    await supabase.from("tasks").insert({
      user_id: user.id,
      title: taskName.trim(),
      status: status === "In Progress" ? "in_progress" : "blocked",
      affected_subsystems: subsystems,
      notes: notes.trim()
    });

    setTaskName("");
    setStatus("In Progress");
    setNotes("");
    setSubsystems([]);
    setIsDialogOpen(false);
    fetchData();
  };

  return (
    <>
      <div className="p-4 flex flex-col gap-6">
        <header className="mb-2 mt-4 flex justify-between items-start">
          <div>
            <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">
              Task Log
            </h1>
            <p className="text-2xl font-mono text-ikrg-text">Session</p>
          </div>
          {canEdit && (
            <Button 
              size="icon" 
              onClick={() => setIsDialogOpen(true)}
              className="h-8 w-8 bg-ikrg-elevated hover:bg-ikrg-border text-ikrg-text border border-ikrg-border"
            >
              <Plus className="h-4 w-4" />
            </Button>
          )}
        </header>
        
        <div className="flex gap-2 font-mono text-[10px] w-full">
          <div className="flex-1 bg-ikrg-green/10 border border-ikrg-green/20 p-2 rounded flex flex-col justify-center items-center">
            <span className="text-ikrg-green font-bold text-lg leading-none">{doneCount}</span>
            <span className="text-ikrg-green/70 mt-1 uppercase tracking-wider">Done</span>
          </div>
          <div className="flex-1 bg-ikrg-amber/10 border border-ikrg-amber/20 p-2 rounded flex flex-col justify-center items-center">
            <span className="text-ikrg-amber font-bold text-lg leading-none">{progressCount}</span>
            <span className="text-ikrg-amber/70 mt-1 uppercase tracking-wider">Active</span>
          </div>
          <div className="flex-1 bg-ikrg-red/10 border border-ikrg-red/20 p-2 rounded flex flex-col justify-center items-center">
            <span className="text-ikrg-red font-bold text-lg leading-none">{blockedCount}</span>
            <span className="text-ikrg-red/70 mt-1 uppercase tracking-wider">Blocked</span>
          </div>
        </div>

        <section className="bg-ikrg-card rounded-lg border border-ikrg-border shadow-none overflow-hidden mt-2">
          <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex items-center justify-between">
            <h3 className="font-mono text-[11px] text-ikrg-text-dim tracking-wider uppercase">Active Tasks</h3>
            <Badge variant="outline" className="bg-[#111] border-ikrg-border text-ikrg-text text-[9px] rounded font-mono px-1.5 py-0">
              {localTasks.length} total
            </Badge>
          </div>
          <div className="px-4 py-2">
            {isLoading ? (
              <div className="py-12 text-center text-ikrg-muted text-[10px] font-mono uppercase tracking-widest animate-pulse">Syncing Session Data...</div>
            ) : localTasks.length > 0 ? (
              localTasks.map((task, i) => (
                <SessionTaskRow key={task.id} task={task} />
              ))
            ) : (
              <div className="py-8 text-center text-ikrg-muted text-sm font-mono">No tasks found.</div>
            )}
          </div>
        </section>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="text-ikrg-text font-mono text-sm tracking-widest uppercase">New Session Task</DialogTitle>
          </DialogHeader>

          <div className="flex flex-col gap-4 mt-2">
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Task Name *</label>
              <Input 
                value={taskName}
                onChange={(e) => setTaskName(e.target.value)}
                placeholder="Ex: Check brake fluid lines" 
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none"
              />
            </div>
            
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Initial Status</label>
              <select 
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text h-8 px-3 py-1 text-xs rounded shadow-none outline-none appearance-none"
              >
                <option value="In Progress">In Progress</option>
                <option value="Blocked">Blocked</option>
              </select>
            </div>

            <div className="space-y-1.5 flex flex-col">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Affected Subsystems</label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                {allSubsystems.map(s => s.name).map(sys => (
                  <div key={sys} onClick={() => toggleSubsystem(sys)} className="flex items-center gap-2 text-xs text-ikrg-muted hover:text-ikrg-text cursor-pointer group">
                    <div className={`w-3 h-3 rounded-sm border flex items-center justify-center transition-colors ${subsystems.includes(sys) ? 'bg-ikrg-red border-ikrg-red' : 'border-ikrg-border bg-ikrg-bg group-hover:border-ikrg-muted'}`}>
                      {subsystems.includes(sys) && <div className="w-1.5 h-1.5 bg-ikrg-bg rounded-sm"></div>}
                    </div>
                    {sys}
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Notes (Optional)</label>
              <textarea 
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text text-xs p-2 rounded shadow-none outline-none min-h-[60px] resize-none"
                placeholder="Log details..."
              />
            </div>
          </div>

          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button 
              className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-8 rounded text-xs" 
              onClick={submitTask}
              disabled={!taskName.trim()}
            >
              Add Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
