"use client";

export const dynamic = "force-dynamic";

import { useAuth } from "@/context/AuthContext";
import { useRole } from "@/hooks/useRole";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useState, useEffect, useCallback } from "react";
import { Plus, Calendar, Clock, ExternalLink } from "lucide-react";

type Meeting = {
  id: string;
  title: string;
  date: string;
  time: string | null;
  organization: string | null;
  purpose: string | null;
  outcome: string | null;
  meeting_minutes: string | null;
  created_at: string;
  users: { name: string } | null;
};

export default function MeetingsPage() {
  const { user } = useAuth();
  const canWrite = useRole("excomm", "sponsorship_team");

  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMeeting, setViewMeeting] = useState<Meeting | null>(null);

  const [addOpen, setAddOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [time, setTime] = useState("");
  const [org, setOrg] = useState("");
  const [purpose, setPurpose] = useState("");
  const [outcome, setOutcome] = useState("");
  const [minutes, setMinutes] = useState("");
  const [saving, setSaving] = useState(false);

  const fetchMeetings = useCallback(async () => {
    const { data } = await supabase
      .from("meetings")
      .select("*, users!created_by(name)")
      .order("date", { ascending: false });
    if (data) setMeetings(data);
    setIsLoading(false);
  }, []);

  useEffect(() => { if (user) fetchMeetings(); }, [fetchMeetings, user]);

  if (!user) return null;

  const saveMeeting = async () => {
    if (!title || !date) return;
    setSaving(true);
    await supabase.from("meetings").insert({
      title: title.trim(),
      date,
      time: time || null,
      organization: org.trim() || null,
      purpose: purpose.trim() || null,
      outcome: outcome.trim() || null,
      meeting_minutes: minutes.trim() || null,
      created_by: user.id,
    });
    setAddOpen(false);
    setTitle(""); setTime(""); setOrg(""); setPurpose(""); setOutcome(""); setMinutes("");
    setSaving(false);
    fetchMeetings();
  };

  const updateOutcome = async (id: string, newOutcome: string, newMinutes: string) => {
    await supabase.from("meetings").update({
      outcome: newOutcome,
      meeting_minutes: newMinutes,
    }).eq("id", id);
    fetchMeetings();
  };

  return (
    <div className="p-4 flex flex-col gap-4 pb-24">
      <header className="mb-2 mt-4 flex justify-between items-end">
        <div>
          <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Records</h1>
          <p className="text-2xl font-mono text-ikrg-text">Meetings</p>
        </div>
        {canWrite && (
          <Button size="sm" onClick={() => setAddOpen(true)} className="h-8 text-xs bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-text font-mono uppercase">
            <Plus className="w-3 h-3 mr-1" /> Meeting
          </Button>
        )}
      </header>

      <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
        <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex justify-between">
          <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">All Meetings</span>
          <span className="font-mono text-[9px] text-ikrg-muted border border-ikrg-border bg-ikrg-bg px-1.5 py-0.5 rounded">{meetings.length} total</span>
        </div>
        {isLoading ? (
          <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse">Loading...</div>
        ) : meetings.length === 0 ? (
          <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No meetings recorded.</div>
        ) : (
          <div className="divide-y divide-ikrg-border/50">
            {meetings.map(m => (
              <button key={m.id} onClick={() => setViewMeeting(m)} className="w-full text-left px-4 py-3 hover:bg-ikrg-elevated transition-colors">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-sm text-ikrg-text">{m.title}</p>
                    {m.organization && <p className="font-mono text-[10px] text-ikrg-amber mt-0.5">{m.organization}</p>}
                    <div className="flex items-center gap-3 mt-1">
                      <span className="font-mono text-[10px] text-ikrg-muted flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> {m.date}
                      </span>
                      {m.time && (
                        <span className="font-mono text-[10px] text-ikrg-muted flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {m.time}
                        </span>
                      )}
                    </div>
                  </div>
                  {m.outcome && (
                    <div className="w-2 h-2 rounded-full bg-ikrg-green flex-shrink-0 mt-1" title="Has outcome" />
                  )}
                </div>
                {m.purpose && <p className="text-[11px] text-ikrg-text-dim mt-1 line-clamp-1">{m.purpose}</p>}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Add Meeting Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Log Meeting</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            {[
              ["Title *", title, setTitle, "text", "Ex: Sponsor call with Bosch"],
              ["Date *", date, setDate, "date", ""],
              ["Time", time, setTime, "time", ""],
              ["Organization", org, setOrg, "text", "Company or body name"],
              ["Purpose", purpose, setPurpose, "text", "Why was this meeting held?"],
            ].map(([label, value, onChange, type, placeholder]) => (
              <div key={label as string} className="space-y-1.5">
                <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">{label as string}</label>
                <Input type={type as string} value={value as string} onChange={e => (onChange as (v: string) => void)(e.target.value)}
                  placeholder={placeholder as string}
                  className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
              </div>
            ))}
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Outcome</label>
              <textarea value={outcome} onChange={e => setOutcome(e.target.value)} placeholder="What was decided?"
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text text-xs p-2 rounded shadow-none outline-none min-h-[60px] resize-none font-sans" />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Meeting Minutes</label>
              <textarea value={minutes} onChange={e => setMinutes(e.target.value)} placeholder="Detailed notes..."
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text text-xs p-2 rounded shadow-none outline-none min-h-[80px] resize-none font-sans" />
            </div>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button disabled={!title || !date || saving} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={saveMeeting}>
              {saving ? "Saving..." : "Log Meeting"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Meeting Dialog */}
      {viewMeeting && (
        <Dialog open={!!viewMeeting} onOpenChange={() => setViewMeeting(null)}>
          <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono max-h-[85vh] overflow-y-auto">
            <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">{viewMeeting.title}</DialogTitle></DialogHeader>
            <div className="flex flex-col gap-3 mt-2 text-xs">
              <div className="flex gap-4">
                <span className="text-ikrg-muted flex items-center gap-1"><Calendar className="w-3 h-3" /> {viewMeeting.date}</span>
                {viewMeeting.time && <span className="text-ikrg-muted flex items-center gap-1"><Clock className="w-3 h-3" /> {viewMeeting.time}</span>}
              </div>
              {viewMeeting.organization && (
                <div>
                  <p className="text-[9px] text-ikrg-text-dim uppercase tracking-wider mb-0.5">Organization</p>
                  <p className="text-ikrg-amber">{viewMeeting.organization}</p>
                </div>
              )}
              {viewMeeting.purpose && (
                <div>
                  <p className="text-[9px] text-ikrg-text-dim uppercase tracking-wider mb-0.5">Purpose</p>
                  <p className="text-ikrg-text">{viewMeeting.purpose}</p>
                </div>
              )}
              {viewMeeting.outcome && (
                <div>
                  <p className="text-[9px] text-ikrg-text-dim uppercase tracking-wider mb-0.5">Outcome</p>
                  <p className="text-ikrg-text">{viewMeeting.outcome}</p>
                </div>
              )}
              {viewMeeting.meeting_minutes && (
                <div>
                  <p className="text-[9px] text-ikrg-text-dim uppercase tracking-wider mb-0.5">Minutes</p>
                  <p className="text-ikrg-text-dim whitespace-pre-wrap leading-relaxed">{viewMeeting.meeting_minutes}</p>
                </div>
              )}
              {viewMeeting.users && (
                <p className="text-[9px] text-ikrg-muted">Logged by {viewMeeting.users.name}</p>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
