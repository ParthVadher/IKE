import { createServerClient, type CookieOptions } from '@supabase/ssr'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase'

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get('code')
  const next = requestUrl.searchParams.get('next') ?? '/dashboard'
  const origin = requestUrl.origin

  console.log("AuthCallback: Received callback", { hasCode: !!code, origin });

  if (code) {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value
          },
          set(name: string, value: string, options: CookieOptions) {
            cookieStore.set({ name, value, ...options })
          },
          remove(name: string, options: CookieOptions) {
            cookieStore.delete({ name, ...options })
          },
        },
      }
    )
    
    const { data: { session }, error } = await supabase.auth.exchangeCodeForSession(code)
    
    if (error) {
      console.error('AuthCallback: Exchange Error:', error.message)
      return NextResponse.redirect(`${origin}/login?error=exchange_failed&message=${encodeURIComponent(error.message)}`)
    }

    if (session) {
      const email = session.user.email
      if (!email) {
        return NextResponse.redirect(`${origin}/login?error=no_email`)
      }

      console.log("AuthCallback: Session established for", email);

      // Gate 1: domain check
      const lowerEmail = email.toLowerCase();
      if (!lowerEmail.endsWith('@pilani.bits-pilani.ac.in') && !lowerEmail.endsWith('@alumni.bits-pilani.ac.in')) {
        console.warn("AuthCallback: Domain mismatch", email);
        await supabase.auth.signOut()
        return NextResponse.redirect(`${origin}/login?error=domain`)
      }

      // Gate 2: allowlist check (users table)
      // Use Admin Client to bypass RLS and ensure the first-time linker can find the record
      const adminSupabase = createAdminClient()
      const { data: userRecord, error: fetchError } = await adminSupabase
        .from('users')
        .select('*')
        .ilike('email', email)
        .single()

      if (fetchError || !userRecord) {
        console.warn("AuthCallback: User not in allowlist", email);
        await supabase.auth.signOut()
        return NextResponse.redirect(`${origin}/login?error=not_allowlisted`)
      }

      // Passed both gates — update auth_id if not set yet
      if (!userRecord.auth_id) {
        console.log("AuthCallback: Linking account identity...");
        const { error: updateError } = await adminSupabase
          .from('users')
          .update({ auth_id: session.user.id })
          .ilike('email', email)
        
        if (updateError) {
          console.error('AuthCallback: Linkage Error:', updateError.message)
        } else {
          console.log("AuthCallback: Identity linkage successful.");
        }
      }

      return NextResponse.redirect(`${origin}${next}`)
    }
  }

  // Fallback for missing code or failed session without error object
  return NextResponse.redirect(`${origin}/login?error=unknown_state`)
}
