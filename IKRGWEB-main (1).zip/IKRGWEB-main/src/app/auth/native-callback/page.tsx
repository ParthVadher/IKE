"use client";

import { useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";

function CallbackHandler() {
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const isNative = typeof window !== 'undefined' &&
      (window as any).Capacitor?.isNativePlatform() === true;

    // On native, AuthContext handles the PKCE exchange via getLaunchUrl() / appUrlOpen.
    // This page just shows the loading UI — do not redirect or interfere.
    if (isNative) return;

    // Web browser path
    const code = searchParams.get("code");
    const error = searchParams.get("error");
    const errorDescription = searchParams.get("error_description");

    if (error) {
      router.replace(`/login?error=${error}&message=${encodeURIComponent(errorDescription || '')}`);
      return;
    }

    if (!code) {
      router.replace("/login");
      return;
    }

    supabase.auth.exchangeCodeForSession(code).then(({ error: exchangeError }) => {
      if (exchangeError) {
        router.replace(`/login?error=exchange_failed&message=${encodeURIComponent(exchangeError.message)}`);
      } else {
        router.replace("/dashboard");
      }
    });
  }, [searchParams, router]);

  return (
    <div className="min-h-screen bg-ikrg-bg text-ikrg-text flex items-center justify-center font-mono uppercase tracking-widest animate-pulse">
      Authenticating...
    </div>
  );
}

export default function AuthCallbackPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-ikrg-bg text-ikrg-text flex items-center justify-center font-mono uppercase tracking-widest animate-pulse">
        Authenticating...
      </div>
    }>
      <CallbackHandler />
    </Suspense>
  );
}
