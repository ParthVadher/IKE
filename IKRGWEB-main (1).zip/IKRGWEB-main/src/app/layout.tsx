import type { Metadata } from "next";
import { IBM_Plex_Sans, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";
import { KeyProvider } from "@/context/KeyContext";
import { SubsystemProvider } from "@/context/SubsystemContext";
import { BottomNav } from "@/components/BottomNav";

const ibmPlexSans = IBM_Plex_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
});

export const metadata: Metadata = {
  title: "Inspired Karters",
  description: "Internal operations dashboard for Inspired Karters Racing Team",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "IKRG",
  },
  icons: {
    apple: [
      { url: "/icons/icon-120.png", sizes: "120x120" },
      { url: "/icons/icon-152.png", sizes: "152x152" },
      { url: "/icons/icon-167.png", sizes: "167x167" },
      { url: "/icons/icon-180.png", sizes: "180x180" },
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <script dangerouslySetInnerHTML={{ __html: `if('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js')` }} />
      </head>
      <body
        className={`${ibmPlexSans.variable} ${jetbrainsMono.variable} font-sans antialiased bg-ikrg-bg text-ikrg-text selection:bg-ikrg-red selection:text-white`}
      >
        <div className="mx-auto max-w-[390px] min-h-screen border-x border-ikrg-border/50 bg-ikrg-bg relative flex flex-col">
          <AuthProvider>
            <SubsystemProvider>
              <KeyProvider>
                <main className="flex-1 pb-20">{children}</main>
                <BottomNav />
              </KeyProvider>
            </SubsystemProvider>
          </AuthProvider>
        </div>
      </body>
    </html>
  );
}
