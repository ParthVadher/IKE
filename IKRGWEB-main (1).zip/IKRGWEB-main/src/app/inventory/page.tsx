"use client";

export const dynamic = "force-dynamic";


import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import { InventoryRow } from "@/components/InventoryRow";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePermission } from "@/hooks/usePermission";
import { useRole } from "@/hooks/useRole";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Plus, Clock, Package, CheckCircle2, ShoppingCart, Truck } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export type InventoryItem = {
  id: string;
  name: string;
  qty: number;
  status: "In Stock" | "Low" | "Out of Stock";
  tab: "We Have" | "Need to Buy";
  urgency?: "High" | "Medium" | "Low";
};

type PendingItem = {
  id: string;
  name: string;
  qty: number;
  priority: string;
  submittedBy: string;
  submittedAt: string;
  approved_status: "pending" | "approved" | "rejected";
  ordered: boolean;
  ordered_at: string | null;
  received: boolean;
  received_at: string | null;
};

const PRIORITY_COLORS: Record<string, string> = {
  high:   "bg-ikrg-red text-white",
  medium: "bg-ikrg-amber text-ikrg-bg",
  low:    "bg-ikrg-muted text-white",
};

const STAGE_META: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  pending:  { label: "Awaiting Approval", color: "text-ikrg-amber", icon: Clock },
  approved: { label: "Approved — Pending Order", color: "text-blue-400",  icon: ShoppingCart },
  ordered:  { label: "Ordered — Awaiting Receipt", color: "text-purple-400", icon: Truck },
};

export default function InventoryPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState<"We Have" | "Need to Buy">("We Have");
  const canEdit    = usePermission(2);
  const canApprove = useRole("excomm", "subsystem_lead");

  const [localItems, setLocalItems]   = useState<InventoryItem[]>([]);
  const [pendingItems, setPendingItems] = useState<PendingItem[]>([]);
  const [isLoading, setIsLoading]     = useState(true);
  const [showNotice, setShowNotice]   = useState(false);

  const [isUpdateOpen, setIsUpdateOpen] = useState(false);
  const [activeItem, setActiveItem]     = useState<InventoryItem | null>(null);
  const [updateQty, setUpdateQty]       = useState(0);
  const [updateStatus, setUpdateStatus] = useState<"In Stock" | "Low" | "Out of Stock">("In Stock");

  const [isAddOpen, setIsAddOpen]   = useState(false);
  const [addName, setAddName]       = useState("");
  const [addQty, setAddQty]         = useState(1);
  const [addPriority, setAddPriority] = useState<"high" | "medium" | "low">("medium");

  const fetchData = useCallback(async () => {
    const { data: invData } = await supabase.from("inventory").select("*");
    if (invData) {
      setLocalItems(invData.map((i: any) => ({
        id: i.id, name: i.name, qty: i.qty,
        status: i.status === "in_stock" ? "In Stock" : i.status === "low" ? "Low" : "Out of Stock",
        tab: i.list === "we_have" ? "We Have" : "Need to Buy",
        urgency: i.urgency,
      })));
    }

    const { data: pendingData } = await supabase
      .from("inventory_pending")
      .select("*, users!submitted_by(username)")
      .neq("approved_status", "rejected")
      .eq("received", false)
      .order("submitted_at", { ascending: false });

    if (pendingData) {
      setPendingItems(pendingData.map((p: any) => ({
        id: p.id,
        name: p.name,
        qty: p.qty,
        priority: (p.priority ?? "medium").toLowerCase(),
        submittedBy: p.users?.username ?? "unknown",
        submittedAt: new Date(p.submitted_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" }),
        approved_status: p.approved_status ?? "pending",
        ordered: p.ordered ?? false,
        ordered_at: p.ordered_at ?? null,
        received: p.received ?? false,
        received_at: p.received_at ?? null,
      })));
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (!user) return;
    fetchData();
    const channel = supabase
      .channel("inventory_changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "inventory" }, () => fetchData())
      .on("postgres_changes", { event: "*", schema: "public", table: "inventory_pending" }, () => fetchData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [fetchData, user]);

  const items = localItems.filter(i => i.tab === tab);

  const openUpdate = (item: InventoryItem) => {
    setActiveItem(item);
    setUpdateQty(item.qty);
    setUpdateStatus(item.status);
    setIsUpdateOpen(true);
  };

  const handleQtyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value) || 0;
    setUpdateQty(val);
    if (val === 0) setUpdateStatus("Out of Stock");
    else if (val === 1) setUpdateStatus("Low");
    else setUpdateStatus("In Stock");
  };

  const submitUpdate = async () => {
    if (!activeItem) return;
    const statusMap = { "In Stock": "in_stock", "Low": "low", "Out of Stock": "out_of_stock" };
    await supabase.from("inventory").update({ qty: updateQty, status: statusMap[updateStatus] }).eq("id", activeItem.id);
    setIsUpdateOpen(false);
    fetchData();
  };

  const submitAdd = async () => {
    if (!addName.trim() || !user) return;
    if (canApprove) {
      const initialStatus = tab === "We Have"
        ? (addQty === 0 ? "out_of_stock" : addQty === 1 ? "low" : "in_stock")
        : "out_of_stock";
      await supabase.from("inventory").insert({ name: addName.trim(), qty: addQty, status: initialStatus, list: tab === "We Have" ? "we_have" : "need_to_buy" });
    } else {
      await supabase.from("inventory_pending").insert({ name: addName.trim(), qty: addQty, priority: addPriority, submitted_by: user.id });
      setShowNotice(true);
      setTimeout(() => setShowNotice(false), 3000);
    }
    setIsAddOpen(false);
    setAddName("");
    setAddQty(1);
    setAddPriority("medium");
    fetchData();
  };

  // Pipeline action handlers
  const approveRequest = async (id: string) => {
    await supabase.from("inventory_pending").update({ approved_status: "approved", approved_at: new Date().toISOString(), approved_by: user?.id }).eq("id", id);
    fetchData();
  };
  const rejectRequest = async (id: string) => {
    await supabase.from("inventory_pending").update({ approved_status: "rejected" }).eq("id", id);
    fetchData();
  };
  const markOrdered = async (id: string) => {
    await supabase.from("inventory_pending").update({ ordered: true, ordered_at: new Date().toISOString() }).eq("id", id);
    fetchData();
  };
  const markReceived = async (id: string) => {
    await supabase.from("inventory_pending").update({ received: true, received_at: new Date().toISOString() }).eq("id", id);
    fetchData();
  };

  const getStageKey = (p: PendingItem): "pending" | "approved" | "ordered" => {
    if (p.approved_status === "pending") return "pending";
    if (p.ordered) return "ordered";
    return "approved";
  };

  return (
    <>
      <div className="p-4 flex flex-col gap-6 pb-24">
        <header className="mb-2 mt-4 flex justify-between items-start">
          <div>
            <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Stock Room</h1>
            <p className="text-2xl font-mono text-ikrg-text">Inventory</p>
          </div>
          {showNotice && (
            <div className="bg-ikrg-green/10 border border-ikrg-green/20 text-ikrg-green text-[10px] font-mono px-3 py-1.5 rounded animate-in fade-in slide-in-from-top-1">
              SUBMITTED FOR APPROVAL
            </div>
          )}
        </header>

        <Tabs defaultValue="We Have" onValueChange={(v) => setTab(v as any)} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-ikrg-elevated border border-ikrg-border p-1 rounded-md h-10 mb-6">
            <TabsTrigger className="data-[state=active]:bg-ikrg-card data-[state=active]:text-ikrg-text text-ikrg-muted text-xs font-mono rounded" value="We Have">WE HAVE</TabsTrigger>
            <TabsTrigger className="data-[state=active]:bg-ikrg-card data-[state=active]:text-ikrg-text text-ikrg-muted text-xs font-mono rounded" value="Need to Buy">NEED TO BUY</TabsTrigger>
          </TabsList>

          <TabsContent value="We Have" className="mt-0 outline-none">
            <div className="bg-ikrg-card border border-ikrg-border rounded-lg p-4">
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-mono text-ikrg-text-dim uppercase">Current Stock</span>
                {canApprove && (
                  <Button size="sm" onClick={() => setIsAddOpen(true)} className="h-7 text-xs bg-ikrg-elevated border-ikrg-border hover:bg-ikrg-border text-ikrg-text shadow-none">
                    <Plus className="h-3 w-3 mr-1" /> Add
                  </Button>
                )}
              </div>
              {isLoading ? (
                <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse">Scanning Shelves...</div>
              ) : (
                items.map(item => <InventoryRow key={item.id} item={item} onUpdate={openUpdate} />)
              )}
            </div>
          </TabsContent>

          <TabsContent value="Need to Buy" className="mt-0 outline-none">
            <div className="flex flex-col gap-4">

              {/* Pipeline section — visible to approvers */}
              {canApprove && (
                <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
                  <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Package className="w-3.5 h-3.5 text-ikrg-amber" />
                      <span className="font-mono text-xs text-ikrg-amber uppercase tracking-widest">Request Pipeline</span>
                    </div>
                    {pendingItems.length > 0 && (
                      <Badge className="bg-ikrg-amber/10 border-ikrg-amber/30 text-ikrg-amber text-[9px] font-mono">
                        {pendingItems.filter(p => p.approved_status === "pending").length} PENDING
                      </Badge>
                    )}
                  </div>

                  {isLoading ? (
                    <div className="py-8 text-center font-mono text-xs text-ikrg-muted animate-pulse">Loading...</div>
                  ) : pendingItems.length === 0 ? (
                    <div className="py-8 text-center flex flex-col items-center gap-2">
                      <CheckCircle2 className="w-6 h-6 text-ikrg-border" />
                      <p className="font-mono text-xs text-ikrg-muted">No pending requests.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-ikrg-border/50">
                      {pendingItems.map(p => {
                        const stageKey = getStageKey(p);
                        const { label: stageLabel, color: stageColor, icon: StageIcon } = STAGE_META[stageKey];
                        return (
                          <div key={p.id} className="px-4 py-3">
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex-1 min-w-0">
                                <p className="font-mono text-sm text-ikrg-text">{p.name}</p>
                                <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                                  <span className="font-mono text-[10px] text-ikrg-text-dim">Qty: {p.qty}</span>
                                  <span className={`font-mono text-[9px] px-1.5 py-0.5 rounded ${PRIORITY_COLORS[p.priority] ?? "bg-ikrg-muted/20 text-ikrg-muted"}`}>
                                    {p.priority.toUpperCase()}
                                  </span>
                                  <span className="font-mono text-[10px] text-ikrg-muted">@{p.submittedBy} · {p.submittedAt}</span>
                                </div>
                                <div className={`flex items-center gap-1 mt-1 ${stageColor}`}>
                                  <StageIcon className="w-3 h-3" />
                                  <span className="font-mono text-[9px] uppercase">{stageLabel}</span>
                                </div>
                              </div>

                              {/* Stage action buttons */}
                              <div className="flex flex-col gap-1.5 flex-shrink-0">
                                {p.approved_status === "pending" && (
                                  <>
                                    <button onClick={() => approveRequest(p.id)}
                                      className="bg-ikrg-green/10 hover:bg-ikrg-green/20 text-ikrg-green border border-ikrg-green/30 px-2 py-1 rounded text-[9px] font-mono uppercase transition-colors">
                                      Approve
                                    </button>
                                    <button onClick={() => rejectRequest(p.id)}
                                      className="bg-ikrg-red/10 hover:bg-ikrg-red/20 text-ikrg-red border border-ikrg-red/30 px-2 py-1 rounded text-[9px] font-mono uppercase transition-colors">
                                      Reject
                                    </button>
                                  </>
                                )}
                                {p.approved_status === "approved" && !p.ordered && (
                                  <button onClick={() => markOrdered(p.id)}
                                    className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 px-2 py-1 rounded text-[9px] font-mono uppercase transition-colors">
                                    Ordered
                                  </button>
                                )}
                                {p.ordered && !p.received && (
                                  <button onClick={() => markReceived(p.id)}
                                    className="bg-ikrg-green/10 hover:bg-ikrg-green/20 text-ikrg-green border border-ikrg-green/30 px-2 py-1 rounded text-[9px] font-mono uppercase transition-colors">
                                    Received
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Purchase list (items already in inventory with need_to_buy list) */}
              <div className="bg-ikrg-card border border-ikrg-border rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-xs font-mono text-ikrg-text-dim uppercase">Purchase List</span>
                  {canEdit && (
                    <Button size="sm" onClick={() => setIsAddOpen(true)} className="h-7 text-xs bg-ikrg-elevated border-ikrg-border hover:bg-ikrg-border text-ikrg-text shadow-none">
                      <Plus className="h-3 w-3 mr-1" /> Request
                    </Button>
                  )}
                </div>
                {isLoading ? (
                  <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse">Fetching Requirements...</div>
                ) : (
                  <>
                    {items.map(item => <InventoryRow key={item.id} item={item} />)}
                    {items.length === 0 && (
                      <div className="py-10 text-center text-ikrg-muted text-sm font-mono">No items backordered.</div>
                    )}
                  </>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Update Stock Dialog */}
      <Dialog open={isUpdateOpen} onOpenChange={setIsUpdateOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="text-ikrg-text font-mono text-sm tracking-widest uppercase">Update Stock</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-2">
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Item</label>
              <Input value={activeItem?.name || ""} disabled className="bg-ikrg-bg border-ikrg-border text-ikrg-muted h-8 text-xs rounded shadow-none opacity-50" />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1.5 col-span-1">
                <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Qty</label>
                <Input type="number" min={0} value={updateQty} onChange={handleQtyChange}
                  className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
              </div>
              <div className="space-y-1.5 col-span-2">
                <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Stock Status</label>
                <select value={updateStatus} onChange={(e) => setUpdateStatus(e.target.value as any)}
                  className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text h-8 px-3 py-1 text-xs rounded shadow-none outline-none appearance-none">
                  <option value="In Stock">In Stock</option>
                  <option value="Low">Low</option>
                  <option value="Out of Stock">Out of Stock</option>
                </select>
              </div>
            </div>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setIsUpdateOpen(false)}>Cancel</Button>
            <Button className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-8 rounded text-xs" onClick={submitUpdate}>Save Item</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add / Request Item Dialog */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="text-ikrg-text font-mono text-sm tracking-widest uppercase">
              {canApprove ? "Add Item" : "Request Item"}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-2">
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Item Name *</label>
              <Input value={addName} onChange={(e) => setAddName(e.target.value)} placeholder="Ex: Lithium Battery Cells"
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Qty {tab === "We Have" ? "Added" : "Needed"}</label>
                <Input type="number" min={1} value={addQty} onChange={(e) => setAddQty(parseInt(e.target.value) || 1)}
                  className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
              </div>
              {tab === "Need to Buy" && (
                <div className="space-y-1.5">
                  <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Priority</label>
                  <select value={addPriority} onChange={(e) => setAddPriority(e.target.value as any)}
                    className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text h-8 px-3 py-1 text-xs rounded shadow-none outline-none appearance-none">
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
              )}
            </div>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setIsAddOpen(false)}>Cancel</Button>
            <Button disabled={!addName.trim()} className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-8 rounded text-xs" onClick={submitAdd}>
              {canApprove ? "Add to List" : "Submit Request"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
