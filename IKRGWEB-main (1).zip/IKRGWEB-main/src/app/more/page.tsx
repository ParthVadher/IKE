"use client";

import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { useRole } from "@/hooks/useRole";
import {
  ListTodo, FileText, Users2, Search, Settings, User,
  Bell, ChevronRight, Calendar
} from "lucide-react";

export default function MorePage() {
  const { user } = useAuth();
  const isExcomm = useRole("excomm");
  const isMentor = useRole("mentors");

  if (!user) return null;

  const sections = [
    {
      title: "Work",
      items: [
        { href: "/session",   icon: ListTodo,  label: "Session Log",    desc: "Your task log"              },
        { href: "/meetings",  icon: Calendar,  label: "Meetings",       desc: "Meeting records & minutes"  },
      ],
    },
    {
      title: "Repository",
      items: [
        { href: "/documents", icon: FileText,  label: "Documents",      desc: "Drive links & submissions"  },
        { href: "/search",    icon: Search,    label: "Global Search",  desc: "Search across all modules"  },
      ],
    },
    {
      title: "Account",
      items: [
        { href: "/notifications", icon: Bell,   label: "Notifications", desc: "Alerts & reminders"         },
        { href: "/profile",       icon: User,   label: "Profile",       desc: "Your identity & team"       },
        ...(isExcomm || isMentor ? [{ href: "/settings", icon: Settings, label: "Settings", desc: "Balances, categories, roles" }] : []),
      ],
    },
  ];

  return (
    <div className="p-4 flex flex-col gap-6 pb-24">
      <header className="mb-2 mt-4">
        <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Navigation</h1>
        <p className="text-2xl font-mono text-ikrg-text">More</p>
      </header>

      {sections.map(section => (
        <section key={section.title}>
          <p className="font-mono text-[10px] text-ikrg-muted uppercase tracking-widest mb-2">{section.title}</p>
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden divide-y divide-ikrg-border">
            {section.items.map(item => (
              <Link key={item.href} href={item.href} className="flex items-center gap-3 px-4 py-3.5 hover:bg-ikrg-elevated transition-colors">
                <item.icon className="w-4 h-4 text-ikrg-text-dim flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-mono text-sm text-ikrg-text">{item.label}</p>
                  <p className="font-mono text-[10px] text-ikrg-muted">{item.desc}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-ikrg-border flex-shrink-0" />
              </Link>
            ))}
          </div>
        </section>
      ))}

      <p className="font-mono text-[9px] text-ikrg-muted/30 uppercase tracking-widest text-center">
        IKE Operations Portal v2
      </p>
    </div>
  );
}
