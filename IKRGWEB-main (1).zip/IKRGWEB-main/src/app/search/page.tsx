"use client";

import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";
import { useState, useCallback } from "react";
import { Search, TrendingDown, TrendingUp, FileText, Handshake, Package, Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";

type ResultType = "transaction" | "sponsor" | "inventory" | "document" | "meeting";

type Result = {
  id: string;
  type: ResultType;
  title: string;
  subtitle: string;
  meta: string;
  badge?: string;
  badgeColor?: string;
};

const TYPE_ICONS: Record<ResultType, React.ElementType> = {
  transaction: TrendingDown,
  sponsor:     Handshake,
  inventory:   Package,
  document:    FileText,
  meeting:     Calendar,
};

const TYPE_LABELS: Record<ResultType, string> = {
  transaction: "Transaction",
  sponsor:     "Sponsor Lead",
  inventory:   "Inventory",
  document:    "Document",
  meeting:     "Meeting",
};

function fmt(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

export default function SearchPage() {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const doSearch = useCallback(async (q: string) => {
    if (!q.trim() || q.trim().length < 2) return;
    setIsSearching(true);
    setHasSearched(true);

    const term = q.trim().toLowerCase();
    const ilike = `%${term}%`;

    const [{ data: txs }, { data: sponsors }, { data: inv }, { data: docs }, { data: meetings }] = await Promise.all([
      supabase.from("transactions").select("id, description, vendor_source, amount, date, type").or(`description.ilike.${ilike},vendor_source.ilike.${ilike}`).limit(5),
      supabase.from("sponsor_leads").select("id, company_name, contact_name, status, created_at").or(`company_name.ilike.${ilike},contact_name.ilike.${ilike}`).limit(5),
      supabase.from("inventory").select("id, name, qty, status").ilike("name", ilike).limit(5),
      supabase.from("documents").select("id, name, type, upload_date").ilike("name", ilike).limit(5),
      supabase.from("meetings").select("id, title, organization, date").or(`title.ilike.${ilike},organization.ilike.${ilike}`).limit(5),
    ]);

    const all: Result[] = [
      ...(txs ?? []).map((t: any) => ({
        id: t.id,
        type: "transaction" as ResultType,
        title: t.description,
        subtitle: t.vendor_source ? `Vendor: ${t.vendor_source}` : "",
        meta: t.date,
        badge: t.type === "income" ? "Income" : "Expense",
        badgeColor: t.type === "income" ? "text-ikrg-green border-ikrg-green/30 bg-ikrg-green/10" : "text-ikrg-red border-ikrg-red/30 bg-ikrg-red/10",
      })),
      ...(sponsors ?? []).map((s: any) => ({
        id: s.id,
        type: "sponsor" as ResultType,
        title: s.company_name,
        subtitle: s.contact_name ?? "",
        meta: s.created_at?.split("T")[0] ?? "",
        badge: s.status,
        badgeColor: "text-ikrg-amber border-ikrg-amber/30 bg-ikrg-amber/10",
      })),
      ...(inv ?? []).map((i: any) => ({
        id: i.id,
        type: "inventory" as ResultType,
        title: i.name,
        subtitle: `Qty: ${i.qty}`,
        meta: i.status?.replace("_", " ") ?? "",
        badge: i.status === "in_stock" ? "In Stock" : i.status === "low" ? "Low" : "Out of Stock",
        badgeColor: i.status === "in_stock" ? "text-ikrg-green border-ikrg-green/30 bg-ikrg-green/10"
          : i.status === "low" ? "text-ikrg-amber border-ikrg-amber/30 bg-ikrg-amber/10"
          : "text-ikrg-red border-ikrg-red/30 bg-ikrg-red/10",
      })),
      ...(docs ?? []).map((d: any) => ({
        id: d.id,
        type: "document" as ResultType,
        title: d.name,
        subtitle: d.type?.replace("_", " ") ?? "",
        meta: d.upload_date ?? "",
      })),
      ...(meetings ?? []).map((m: any) => ({
        id: m.id,
        type: "meeting" as ResultType,
        title: m.title,
        subtitle: m.organization ?? "",
        meta: m.date ?? "",
      })),
    ];

    setResults(all);
    setIsSearching(false);
  }, []);

  if (!user) return null;

  return (
    <div className="p-4 flex flex-col gap-4 pb-24">
      <header className="mb-2 mt-4">
        <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Portal</h1>
        <p className="text-2xl font-mono text-ikrg-text">Global Search</p>
      </header>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ikrg-muted" />
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === "Enter" && doSearch(query)}
          placeholder="Search transactions, sponsors, inventory..."
          className="w-full bg-ikrg-card border border-ikrg-border text-ikrg-text h-10 pl-10 pr-4 text-sm rounded-lg outline-none font-sans focus:border-ikrg-text/30 transition-colors"
        />
        {query && (
          <button
            onClick={() => doSearch(query)}
            className="absolute right-3 top-1/2 -translate-y-1/2 font-mono text-[9px] text-ikrg-muted hover:text-ikrg-text uppercase tracking-wider"
          >
            Search
          </button>
        )}
      </div>

      {isSearching && (
        <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse uppercase tracking-widest">Searching...</div>
      )}

      {!isSearching && hasSearched && results.length === 0 && (
        <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No results for "{query}".</div>
      )}

      {!isSearching && results.length > 0 && (
        <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
          <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2">
            <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">{results.length} results</span>
          </div>
          <div className="divide-y divide-ikrg-border/50">
            {results.map(r => {
              const Icon = TYPE_ICONS[r.type];
              return (
                <div key={r.id} className="px-4 py-3 flex items-start gap-3">
                  <Icon className="w-4 h-4 text-ikrg-muted flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-mono text-sm text-ikrg-text">{r.title}</p>
                      {r.badge && (
                        <Badge className={`text-[9px] font-mono border ${r.badgeColor}`}>{r.badge}</Badge>
                      )}
                    </div>
                    {r.subtitle && <p className="font-mono text-[10px] text-ikrg-muted mt-0.5">{r.subtitle}</p>}
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="font-mono text-[9px] text-ikrg-muted uppercase">{TYPE_LABELS[r.type]}</span>
                      {r.meta && <span className="font-mono text-[9px] text-ikrg-muted">{r.meta}</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {!hasSearched && (
        <div className="flex flex-col gap-2 mt-4">
          <p className="font-mono text-[10px] text-ikrg-muted uppercase tracking-widest">Searches across</p>
          {(["Transactions & Vendors", "Sponsor Leads & Contacts", "Inventory Items", "Documents", "Meetings & Organizations"] as const).map(label => (
            <div key={label} className="flex items-center gap-2 font-mono text-xs text-ikrg-text-dim">
              <div className="w-1 h-1 rounded-full bg-ikrg-border" />
              {label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
