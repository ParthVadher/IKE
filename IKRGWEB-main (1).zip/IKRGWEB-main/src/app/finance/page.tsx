"use client";

export const dynamic = "force-dynamic";

import { useAuth } from "@/context/AuthContext";
import { useRole } from "@/hooks/useRole";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useState, useEffect, useCallback, useMemo } from "react";
import { Plus, TrendingUp, TrendingDown, AlertCircle, FileText } from "lucide-react";

type Account = "bank" | "dean" | "bitsaa";
type TxType = "income" | "expense";

type Transaction = {
  id: string;
  date: string;
  account: Account;
  type: TxType;
  amount: number;
  description: string;
  vendor_source: string | null;
  payment_method: string | null;
  is_reimbursable: boolean;
  invoice_url: string | null;
  gst_bill_url: string | null;
  invoice_attached: boolean;
  gst_bill_available: boolean;
  departments: { name: string } | null;
  categories: { name: string } | null;
};

type Reimbursement = {
  id: string;
  transaction_id: string;
  date: string;
  vendor: string | null;
  description: string;
  amount: number;
  invoice_uploaded: boolean;
  gst_uploaded: boolean;
  status: string;
  submission_date: string | null;
  reimbursement_date: string | null;
};

type FestExpense = {
  id: string;
  fest_name: string;
  date: string;
  description: string;
  amount: number;
  departments: { name: string } | null;
};

type Balances = {
  bank_balance: number;
  dean_balance: number;
  bitsaa_balance: number;
};

type Category = { id: string; name: string };
type Department = { id: string; name: string };

function Select({ label, value, onChange, children }: { label: string; value: string; onChange: (v: string) => void; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider font-mono">{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)}
        className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text h-8 px-2 text-xs rounded shadow-none outline-none appearance-none font-mono">
        {children}
      </select>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder = "" }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <div className="space-y-1.5">
      <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider font-mono">{label}</label>
      <Input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none font-mono" />
    </div>
  );
}

const STATUS_COLORS: Record<string, string> = {
  pending_submission: "bg-ikrg-muted/10 text-ikrg-muted border-ikrg-muted/30",
  submitted:          "bg-blue-900/20 text-blue-400 border-blue-800/30",
  under_review:       "bg-ikrg-amber/10 text-ikrg-amber border-ikrg-amber/30",
  approved:           "bg-green-900/20 text-green-400 border-green-800/30",
  reimbursed:         "bg-ikrg-green/10 text-ikrg-green border-ikrg-green/30",
  rejected:           "bg-ikrg-red/10 text-ikrg-red border-ikrg-red/30",
};

const STATUS_LABELS: Record<string, string> = {
  pending_submission: "Pending",
  submitted:          "Submitted",
  under_review:       "In Review",
  approved:           "Approved",
  reimbursed:         "Reimbursed",
  rejected:           "Rejected",
};

function fmt(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

export default function FinancePage() {
  const { user } = useAuth();
  const isExcomm = useRole("excomm");

  const [balances, setBalances] = useState<Balances | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [reimbursements, setReimbursements] = useState<Reimbursement[]>([]);
  const [festExpenses, setFestExpenses] = useState<FestExpense[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Transaction form state
  const [txOpen, setTxOpen] = useState(false);
  const [txDate, setTxDate] = useState(new Date().toISOString().split("T")[0]);
  const [txAccount, setTxAccount] = useState<Account>("bank");
  const [txType, setTxType] = useState<TxType>("expense");
  const [txAmount, setTxAmount] = useState("");
  const [txDesc, setTxDesc] = useState("");
  const [txVendor, setTxVendor] = useState("");
  const [txPayment, setTxPayment] = useState("");
  const [txCatId, setTxCatId] = useState("");
  const [txDeptId, setTxDeptId] = useState("");
  const [txInvoiceUrl, setTxInvoiceUrl] = useState("");
  const [txGstUrl, setTxGstUrl] = useState("");
  const [txReimbursable, setTxReimbursable] = useState(false);
  const [txRemarks, setTxRemarks] = useState("");
  const [txSaving, setTxSaving] = useState(false);

  // Reimbursement status edit
  const [reimOpen, setReimOpen] = useState(false);
  const [editReim, setEditReim] = useState<Reimbursement | null>(null);
  const [reimStatus, setReimStatus] = useState("");
  const [reimDate, setReimDate] = useState("");
  const [reimRemarks, setReimRemarks] = useState("");

  // Fest form
  const [festOpen, setFestOpen] = useState(false);
  const [festName, setFestName] = useState("");
  const [festDate, setFestDate] = useState(new Date().toISOString().split("T")[0]);
  const [festDesc, setFestDesc] = useState("");
  const [festAmount, setFestAmount] = useState("");
  const [festDeptId, setFestDeptId] = useState("");
  const [festTxId, setFestTxId] = useState("");
  const [festSaving, setFestSaving] = useState(false);

  const fetchAll = useCallback(async () => {
    const [{ data: bal }, { data: txs }, { data: reims }, { data: fests }, { data: cats }, { data: depts }] = await Promise.all([
      supabase.from("account_balances").select("*").single(),
      supabase.from("transactions").select("*, departments(name), categories(name)").order("date", { ascending: false }).limit(100),
      supabase.from("reimbursements").select("*").order("created_at", { ascending: false }),
      supabase.from("fest_expenses").select("*, departments(name)").order("date", { ascending: false }),
      supabase.from("categories").select("id, name").order("name"),
      supabase.from("departments").select("id, name").order("name"),
    ]);
    if (bal) setBalances(bal);
    if (txs) setTransactions(txs);
    if (reims) setReimbursements(reims);
    if (fests) setFestExpenses(fests);
    if (cats) setCategories(cats);
    if (depts) setDepartments(depts);
    setIsLoading(false);
  }, []);

  useEffect(() => { if (user && isExcomm) fetchAll(); }, [fetchAll, user, isExcomm]);

  const totalIncome = useMemo(() => transactions.filter(t => t.type === "income").reduce((s, t) => s + t.amount, 0), [transactions]);
  const totalExpense = useMemo(() => transactions.filter(t => t.type === "expense").reduce((s, t) => s + t.amount, 0), [transactions]);
  const monthlyData = useMemo(() => {
    const months = Array.from({ length: 6 }, (_, idx) => {
      const d = new Date();
      d.setMonth(d.getMonth() - (5 - idx));
      return { key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`, label: d.toLocaleString("en-IN", { month: "short" }), income: 0, expense: 0 };
    });
    transactions.forEach(tx => {
      const m = months.find(mo => mo.key === tx.date.slice(0, 7));
      if (m) { if (tx.type === "income") m.income += tx.amount; else m.expense += tx.amount; }
    });
    return months;
  }, [transactions]);
  const deptData = useMemo(() => {
    const map: Record<string, number> = {};
    transactions.filter(t => t.type === "expense" && t.departments).forEach(tx => { const n = tx.departments!.name; map[n] = (map[n] || 0) + tx.amount; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [transactions]);

  if (!user) return null;
  if (!isExcomm) return (
    <div className="p-6 pt-16 text-center font-mono text-xs text-ikrg-muted uppercase tracking-widest">
      ExComm Access Only
    </div>
  );

  const saveTransaction = async () => {
    if (!txAmount || !txDesc) return;
    setTxSaving(true);
    await supabase.from("transactions").insert({
      date: txDate,
      account: txAccount,
      type: txType,
      amount: parseFloat(txAmount),
      description: txDesc.trim(),
      vendor_source: txVendor.trim() || null,
      payment_method: txPayment.trim() || null,
      category_id: txCatId || null,
      department_id: txDeptId || null,
      invoice_url: txInvoiceUrl.trim() || null,
      gst_bill_url: txGstUrl.trim() || null,
      invoice_attached: !!txInvoiceUrl.trim(),
      gst_bill_available: !!txGstUrl.trim(),
      is_reimbursable: txReimbursable,
      remarks: txRemarks.trim() || null,
      created_by: user.id,
    });
    setTxOpen(false);
    setTxAmount(""); setTxDesc(""); setTxVendor(""); setTxPayment("");
    setTxCatId(""); setTxDeptId(""); setTxInvoiceUrl(""); setTxGstUrl("");
    setTxReimbursable(false); setTxRemarks("");
    setTxSaving(false);
    fetchAll();
  };

  const saveReimStatus = async () => {
    if (!editReim) return;
    await supabase.from("reimbursements").update({
      status: reimStatus,
      reimbursement_date: reimStatus === "reimbursed" ? reimDate || null : null,
      submission_date: reimStatus === "submitted" ? reimDate || null : editReim.submission_date,
      updated_by: user.id,
    }).eq("id", editReim.id);
    setReimOpen(false);
    fetchAll();
  };

  const saveFest = async () => {
    if (!festName || !festAmount || !festDesc) return;
    setFestSaving(true);
    await supabase.from("fest_expenses").insert({
      fest_name: festName.trim(),
      date: festDate,
      description: festDesc.trim(),
      amount: parseFloat(festAmount),
      department_id: festDeptId || null,
      transaction_id: festTxId || null,
      created_by: user.id,
    });
    setFestOpen(false);
    setFestName(""); setFestDesc(""); setFestAmount(""); setFestDeptId(""); setFestTxId("");
    setFestSaving(false);
    fetchAll();
  };

  const openReimEdit = (r: Reimbursement) => {
    setEditReim(r);
    setReimStatus(r.status);
    setReimDate(r.reimbursement_date || r.submission_date || "");
    setReimRemarks("");
    setReimOpen(true);
  };

  return (
    <div className="p-4 flex flex-col gap-4 pb-24">
      <header className="mb-2 mt-4 flex justify-between items-end">
        <div>
          <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Treasury</h1>
          <p className="text-2xl font-mono text-ikrg-text">Finance</p>
        </div>
        {isExcomm && (
          <Button size="sm" onClick={() => setTxOpen(true)} className="h-8 text-xs bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-text font-mono uppercase">
            <Plus className="w-3 h-3 mr-1" /> Transaction
          </Button>
        )}
      </header>

      {/* Balances row */}
      {balances && (
        <div className="grid grid-cols-3 gap-2">
          {([["Bank", balances.bank_balance], ["Dean", balances.dean_balance], ["BITSAA", balances.bitsaa_balance]] as [string, number][]).map(([label, val]) => (
            <div key={label} className="bg-ikrg-card border border-ikrg-border rounded-lg p-3 text-center">
              <p className="font-mono text-[9px] text-ikrg-muted uppercase tracking-widest mb-1">{label}</p>
              <p className={`font-mono text-sm font-bold ${val >= 0 ? "text-ikrg-green" : "text-ikrg-red"}`}>{fmt(val)}</p>
            </div>
          ))}
        </div>
      )}

      <Tabs defaultValue="charts" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-ikrg-elevated border border-ikrg-border p-1 rounded-md h-9 mb-4">
          {[["charts", "Charts"], ["transactions", "Txns"], ["reimbursements", "Reimb"], ["fest", "Fest"]].map(([v, l]) => (
            <TabsTrigger key={v} value={v} className="data-[state=active]:bg-ikrg-card data-[state=active]:text-ikrg-text text-ikrg-muted text-[10px] font-mono rounded uppercase">
              {l}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Charts */}
        <TabsContent value="charts" className="mt-0 outline-none flex flex-col gap-4">
          {/* Income vs Expense */}
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2">
              <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">Income vs Expense</span>
            </div>
            <div className="p-4 flex flex-col gap-3">
              {[
                { label: "Income",  val: totalIncome,  barCls: "bg-green-500/25", textCls: "text-green-400" },
                { label: "Expense", val: totalExpense, barCls: "bg-red-500/25",   textCls: "text-red-400"   },
              ].map(({ label, val, barCls, textCls }) => {
                const pct = Math.round((val / Math.max(totalIncome, totalExpense, 1)) * 100);
                return (
                  <div key={label} className="flex items-center gap-3">
                    <span className="font-mono text-[10px] text-ikrg-muted uppercase w-16">{label}</span>
                    <div className="flex-1 bg-ikrg-elevated rounded h-7 overflow-hidden relative">
                      <div className={`absolute inset-y-0 left-0 ${barCls} transition-all`} style={{ width: `${pct}%` }} />
                      <div className="absolute inset-0 flex items-center pl-2">
                        <span className={`font-mono text-[10px] font-bold ${textCls}`}>{fmt(val)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div className="flex justify-between font-mono text-[9px] text-ikrg-muted pt-1 border-t border-ikrg-border/30 mt-1">
                <span>NET: <span className={totalIncome - totalExpense >= 0 ? "text-green-400" : "text-red-400"}>{fmt(totalIncome - totalExpense)}</span></span>
                <span>{transactions.length} transactions</span>
              </div>
            </div>
          </div>

          {/* Monthly Chart */}
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2">
              <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">Monthly (Last 6 Months)</span>
            </div>
            <div className="p-4">
              <svg viewBox="0 0 280 90" className="w-full">
                {(() => {
                  const maxV = Math.max(1, ...monthlyData.flatMap(d => [d.income, d.expense]));
                  const slotW = 280 / 6;
                  const bW = slotW * 0.28;
                  return monthlyData.map((m, i) => {
                    const incH = Math.max(0, (m.income / maxV) * 66);
                    const expH = Math.max(0, (m.expense / maxV) * 66);
                    const gX = i * slotW + slotW * 0.1;
                    return (
                      <g key={m.key}>
                        <rect x={gX} y={70 - incH} width={bW} height={Math.max(incH, 0.5)} fill="#4ade80" opacity={0.55} rx={1} />
                        <rect x={gX + bW + 2} y={70 - expH} width={bW} height={Math.max(expH, 0.5)} fill="#f87171" opacity={0.55} rx={1} />
                        <text x={gX + bW + 1} y={84} textAnchor="middle" fontSize={8} fill="#6b7280">{m.label}</text>
                      </g>
                    );
                  });
                })()}
                <line x1={0} y1={70} x2={280} y2={70} stroke="#374151" strokeWidth={1} />
              </svg>
              <div className="flex gap-4 mt-1">
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-sm" style={{ background: "rgba(74,222,128,0.55)" }} /><span className="font-mono text-[9px] text-ikrg-muted">Income</span></div>
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-sm" style={{ background: "rgba(248,113,113,0.55)" }} /><span className="font-mono text-[9px] text-ikrg-muted">Expense</span></div>
              </div>
            </div>
          </div>

          {/* Spending by Department */}
          {deptData.length > 0 && (
            <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
              <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2">
                <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">Spending by Dept</span>
              </div>
              <div className="p-4 flex flex-col gap-2">
                {deptData.map(([name, val]) => {
                  const pct = Math.round((val / deptData[0][1]) * 100);
                  return (
                    <div key={name} className="flex items-center gap-2">
                      <span className="font-mono text-[9px] text-ikrg-muted w-20 truncate" title={name}>{name}</span>
                      <div className="flex-1 bg-ikrg-elevated rounded h-5 overflow-hidden relative">
                        <div className="absolute inset-y-0 left-0 bg-red-500/20" style={{ width: `${pct}%` }} />
                        <div className="absolute inset-0 flex items-center justify-end pr-2">
                          <span className="font-mono text-[9px] text-ikrg-muted">{fmt(val)}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {transactions.length === 0 && !isLoading && (
            <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No transaction data yet.</div>
          )}
        </TabsContent>

        {/* Transactions */}
        <TabsContent value="transactions" className="mt-0 outline-none">
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex justify-between items-center">
              <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">All Transactions</span>
              <span className="font-mono text-[9px] text-ikrg-muted border border-ikrg-border bg-ikrg-bg px-1.5 py-0.5 rounded">{transactions.length} total</span>
            </div>
            {isLoading ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse uppercase tracking-widest">Loading...</div>
            ) : transactions.length === 0 ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No transactions yet.</div>
            ) : (
              <div className="divide-y divide-ikrg-border/50">
                {transactions.map(tx => (
                  <div key={tx.id} className="px-4 py-3 flex items-start gap-3">
                    <div className="mt-0.5">
                      {tx.type === "income"
                        ? <TrendingUp className="w-4 h-4 text-ikrg-green" />
                        : <TrendingDown className="w-4 h-4 text-ikrg-red" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-mono text-sm text-ikrg-text truncate">{tx.description}</p>
                        <p className={`font-mono text-sm font-bold flex-shrink-0 ${tx.type === "income" ? "text-ikrg-green" : "text-ikrg-red"}`}>
                          {tx.type === "income" ? "+" : "-"}{fmt(tx.amount)}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                        <span className="font-mono text-[10px] text-ikrg-muted">{tx.date}</span>
                        <span className="font-mono text-[10px] text-ikrg-muted uppercase">{tx.account}</span>
                        {tx.departments && <span className="font-mono text-[10px] text-ikrg-muted">{tx.departments.name}</span>}
                        {tx.categories && <Badge className="text-[9px] font-mono bg-ikrg-elevated border-ikrg-border text-ikrg-text-dim px-1 py-0">{tx.categories.name}</Badge>}
                        {tx.is_reimbursable && <Badge className="text-[9px] font-mono bg-ikrg-amber/10 border-ikrg-amber/30 text-ikrg-amber px-1 py-0">Reimbursable</Badge>}
                        {tx.invoice_url && (
                          <a href={tx.invoice_url} target="_blank" rel="noreferrer" className="text-[9px] text-blue-400 font-mono flex items-center gap-0.5 hover:underline">
                            <FileText className="w-2.5 h-2.5" /> INV
                          </a>
                        )}
                      </div>
                      {tx.vendor_source && <p className="font-mono text-[10px] text-ikrg-muted mt-0.5">Vendor: {tx.vendor_source}</p>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Reimbursements */}
        <TabsContent value="reimbursements" className="mt-0 outline-none">
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex justify-between items-center">
              <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">Reimbursements</span>
              <span className="font-mono text-[9px] text-ikrg-muted border border-ikrg-border bg-ikrg-bg px-1.5 py-0.5 rounded">{reimbursements.filter(r => r.status !== "reimbursed").length} pending</span>
            </div>
            {isLoading ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse uppercase tracking-widest">Loading...</div>
            ) : reimbursements.length === 0 ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No reimbursements.</div>
            ) : (
              <div className="divide-y divide-ikrg-border/50">
                {reimbursements.map(r => {
                  const daysPending = Math.floor((Date.now() - new Date(r.date).getTime()) / 86400000);
                  const isOverdue = daysPending > 30 && r.status === "pending_submission";
                  return (
                    <div key={r.id} className={`px-4 py-3 ${isOverdue ? "bg-ikrg-red/5" : ""}`}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-mono text-sm text-ikrg-text truncate">{r.description}</p>
                          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                            <span className="font-mono text-[10px] text-ikrg-muted">{r.date}</span>
                            {r.vendor && <span className="font-mono text-[10px] text-ikrg-muted">{r.vendor}</span>}
                            {!r.invoice_uploaded && <span className="font-mono text-[9px] text-ikrg-red flex items-center gap-0.5"><AlertCircle className="w-2.5 h-2.5" /> No invoice</span>}
                            {!r.gst_uploaded && <span className="font-mono text-[9px] text-ikrg-amber flex items-center gap-0.5"><AlertCircle className="w-2.5 h-2.5" /> No GST</span>}
                            {isOverdue && <span className="font-mono text-[9px] text-ikrg-red">OVERDUE {daysPending}d</span>}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                          <p className="font-mono text-sm font-bold text-ikrg-amber">{fmt(r.amount)}</p>
                          <Badge className={`text-[9px] font-mono border ${STATUS_COLORS[r.status]}`}>{STATUS_LABELS[r.status]}</Badge>
                          {isExcomm && (
                            <button onClick={() => openReimEdit(r)} className="font-mono text-[9px] text-ikrg-muted hover:text-ikrg-text uppercase">Edit →</button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Fest Expenses */}
        <TabsContent value="fest" className="mt-0 outline-none">
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex justify-between items-center">
              <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">Fest Expenses</span>
              {isExcomm && (
                <button onClick={() => setFestOpen(true)} className="text-ikrg-muted hover:text-ikrg-text transition-colors">
                  <Plus className="w-4 h-4" />
                </button>
              )}
            </div>
            {isLoading ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse uppercase tracking-widest">Loading...</div>
            ) : festExpenses.length === 0 ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No fest expenses.</div>
            ) : (
              <div className="divide-y divide-ikrg-border/50">
                {festExpenses.map(f => (
                  <div key={f.id} className="px-4 py-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <Badge className="text-[9px] font-mono bg-ikrg-red/10 border-ikrg-red/30 text-ikrg-red mb-1">{f.fest_name}</Badge>
                        <p className="font-mono text-sm text-ikrg-text">{f.description}</p>
                        <p className="font-mono text-[10px] text-ikrg-muted mt-0.5">{f.date}{f.departments ? ` · ${f.departments.name}` : ""}</p>
                      </div>
                      <p className="font-mono text-sm font-bold text-ikrg-red flex-shrink-0">{fmt(f.amount)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Add Transaction Dialog */}
      <Dialog open={txOpen} onOpenChange={setTxOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Add Transaction</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            <Field label="Date" type="date" value={txDate} onChange={setTxDate} />
            <div className="grid grid-cols-2 gap-2">
              <Select label="Account" value={txAccount} onChange={v => setTxAccount(v as Account)}>
                <option value="bank">Bank</option>
                <option value="dean">Dean</option>
                <option value="bitsaa">BITSAA</option>
              </Select>
              <Select label="Type" value={txType} onChange={v => setTxType(v as TxType)}>
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </Select>
            </div>
            <Field label="Amount (₹)" type="number" value={txAmount} onChange={setTxAmount} placeholder="0.00" />
            <Field label="Description *" value={txDesc} onChange={setTxDesc} placeholder="What was this for?" />
            <Field label="Vendor / Source" value={txVendor} onChange={setTxVendor} placeholder="Vendor name" />
            <Field label="Payment Method" value={txPayment} onChange={setTxPayment} placeholder="UPI / Cash / Bank" />
            <div className="grid grid-cols-2 gap-2">
              <Select label="Department" value={txDeptId} onChange={setTxDeptId}>
                <option value="">None</option>
                {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
              </Select>
              <Select label="Category" value={txCatId} onChange={setTxCatId}>
                <option value="">None</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </Select>
            </div>
            <Field label="Invoice URL (Drive)" value={txInvoiceUrl} onChange={setTxInvoiceUrl} placeholder="https://drive.google.com/..." />
            <Field label="GST Bill URL (Drive)" value={txGstUrl} onChange={setTxGstUrl} placeholder="https://drive.google.com/..." />
            <Field label="Remarks" value={txRemarks} onChange={setTxRemarks} placeholder="Optional notes" />
            <label className="flex items-center gap-2 cursor-pointer mt-1">
              <input type="checkbox" checked={txReimbursable} onChange={e => setTxReimbursable(e.target.checked)} className="accent-ikrg-red w-4 h-4" />
              <span className="text-[10px] text-ikrg-text font-mono uppercase">Reimbursable from Dean</span>
            </label>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setTxOpen(false)}>Cancel</Button>
            <Button disabled={!txAmount || !txDesc || txSaving} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={saveTransaction}>
              {txSaving ? "Saving..." : "Add Transaction"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Reimbursement Status Dialog */}
      <Dialog open={reimOpen} onOpenChange={setReimOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Update Status</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            {editReim && <p className="text-xs text-ikrg-text-dim">{editReim.description} — {fmt(editReim.amount)}</p>}
            <Select label="Status" value={reimStatus} onChange={setReimStatus}>
              {Object.entries(STATUS_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </Select>
            {(reimStatus === "submitted" || reimStatus === "reimbursed") && (
              <Field label={reimStatus === "reimbursed" ? "Reimbursement Date" : "Submission Date"} type="date" value={reimDate} onChange={setReimDate} />
            )}
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setReimOpen(false)}>Cancel</Button>
            <Button className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={saveReimStatus}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Fest Expense Dialog */}
      <Dialog open={festOpen} onOpenChange={setFestOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Add Fest Expense</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            <Field label="Fest Name" value={festName} onChange={setFestName} placeholder="Ex: Oasis 2025" />
            <Field label="Date" type="date" value={festDate} onChange={setFestDate} />
            <Field label="Description *" value={festDesc} onChange={setFestDesc} placeholder="What was purchased?" />
            <Field label="Amount (₹)" type="number" value={festAmount} onChange={setFestAmount} placeholder="0.00" />
            <Select label="Department" value={festDeptId} onChange={setFestDeptId}>
              <option value="">None</option>
              {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setFestOpen(false)}>Cancel</Button>
            <Button disabled={!festName || !festDesc || !festAmount || festSaving} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={saveFest}>
              {festSaving ? "Saving..." : "Add Expense"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
