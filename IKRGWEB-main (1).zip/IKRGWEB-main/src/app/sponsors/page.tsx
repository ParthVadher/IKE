"use client";

export const dynamic = "force-dynamic";

import { useAuth } from "@/context/AuthContext";
import { useRole } from "@/hooks/useRole";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useState, useEffect, useCallback } from "react";
import { Plus, ExternalLink, Trophy } from "lucide-react";

type Status = "researching"|"contacted"|"followup"|"meeting_scheduled"|"proposal_sent"|"negotiation"|"won"|"lost";

type Lead = {
  id: string;
  company_name: string;
  category: "Sponsor" | "Vendor";
  contact_name: string | null;
  contact_info: string | null;
  phone: string | null;
  contact_method: string | null;
  notes: string | null;
  status: Status;
  first_contact_date: string | null;
  next_followup_date: string | null;
  created_at: string;
  poc_user_id: string | null;
  users: { name: string } | null;
  poc: { name: string } | null;
};

type ManagementMember = { id: string; name: string };

type ActiveSponsor = {
  id: string;
  name: string;
  sponsorship_type: "cash" | "in_kind" | "both";
  cash_value: number;
  in_kind_estimated_value: number;
  total_value: number;
  deliverables_promised: string | null;
  mou_url: string | null;
  date_received: string | null;
};

const STATUS_ORDER: Status[] = ["researching","contacted","followup","meeting_scheduled","proposal_sent","negotiation","won","lost"];

const STATUS_STYLES: Record<Status, string> = {
  researching:       "bg-ikrg-muted/10 text-ikrg-muted border-ikrg-muted/30",
  contacted:         "bg-blue-900/20 text-blue-400 border-blue-800/30",
  followup:          "bg-ikrg-amber/10 text-ikrg-amber border-ikrg-amber/30",
  meeting_scheduled: "bg-purple-900/20 text-purple-400 border-purple-800/30",
  proposal_sent:     "bg-orange-900/20 text-orange-400 border-orange-800/30",
  negotiation:       "bg-yellow-900/20 text-yellow-400 border-yellow-800/30",
  won:               "bg-ikrg-green/10 text-ikrg-green border-ikrg-green/30",
  lost:              "bg-ikrg-red/10 text-ikrg-red border-ikrg-red/30",
};

const STATUS_LABELS: Record<Status, string> = {
  researching: "Researching", contacted: "Contacted", followup: "Follow-up",
  meeting_scheduled: "Meeting Set", proposal_sent: "Proposal Sent",
  negotiation: "Negotiation", won: "Won", lost: "Lost",
};

function fmt(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

export default function SponsorsPage() {
  const { user } = useAuth();
  const canWrite = useRole("excomm", "sponsorship_team");

  const [leads, setLeads] = useState<Lead[]>([]);
  const [active, setActive] = useState<ActiveSponsor[]>([]);
  const [managementMembers, setManagementMembers] = useState<ManagementMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [addOpen, setAddOpen] = useState(false);
  const [company, setCompany] = useState("");
  const [category, setCategory] = useState<"Sponsor"|"Vendor">("Sponsor");
  const [contactName, setContactName] = useState("");
  const [contactInfo, setContactInfo] = useState("");
  const [phone, setPhone] = useState("");
  const [contactMethod, setContactMethod] = useState("email");
  const [poc, setPoc] = useState("");
  const [notes, setNotes] = useState("");
  const [firstContact, setFirstContact] = useState("");
  const [nextFollowup, setNextFollowup] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const [editOpen, setEditOpen] = useState(false);
  const [editLead, setEditLead] = useState<Lead | null>(null);
  const [editStatus, setEditStatus] = useState<Status>("researching");
  const [editNextFollowup, setEditNextFollowup] = useState("");
  const [editNotes, setEditNotes] = useState("");
  const [editPoc, setEditPoc] = useState("");

  const fetchAll = useCallback(async () => {
    const [{ data: l }, { data: a }, { data: m }] = await Promise.all([
      supabase.from("sponsor_leads").select("*, users!submitted_by(name), poc:users!poc_user_id(name)").order("created_at", { ascending: false }),
      supabase.from("active_sponsors").select("*").order("date_received", { ascending: false }),
      supabase.from("users").select("id, name").ilike("subsystem", "Management%").order("name"),
    ]);
    if (l) setLeads(l);
    if (a) setActive(a);
    if (m) setManagementMembers(m);
    setIsLoading(false);
  }, []);

  useEffect(() => { if (user) fetchAll(); }, [fetchAll, user]);

  if (!user) return null;

  const addLead = async () => {
    if (!company.trim()) return;
    setSubmitting(true);
    await supabase.from("sponsor_leads").insert({
      submitted_by: user.id,
      company_name: company.trim(),
      category,
      contact_name: contactName.trim() || null,
      contact_info: contactInfo.trim() || null,
      phone: phone.trim() || null,
      contact_method: contactMethod,
      poc_user_id: poc || null,
      notes: notes.trim() || null,
      first_contact_date: firstContact || null,
      next_followup_date: nextFollowup || null,
      status: "researching",
    });
    setAddOpen(false);
    setCompany(""); setContactName(""); setContactInfo(""); setPhone(""); setPoc(""); setNotes(""); setFirstContact(""); setNextFollowup("");
    setSubmitting(false);
    fetchAll();
  };

  const openEdit = (lead: Lead) => {
    setEditLead(lead);
    setEditStatus(lead.status);
    setEditNextFollowup(lead.next_followup_date ?? "");
    setEditNotes(lead.notes ?? "");
    setEditPoc(lead.poc_user_id ?? "");
    setEditOpen(true);
  };

  const saveEdit = async () => {
    if (!editLead) return;
    await supabase.from("sponsor_leads").update({
      status: editStatus,
      next_followup_date: editNextFollowup || null,
      notes: editNotes.trim() || null,
      poc_user_id: editPoc || null,
      updated_by: user.id,
    }).eq("id", editLead.id);
    setEditOpen(false);
    fetchAll();
  };

  const pipeline = STATUS_ORDER.filter(s => s !== "lost" && s !== "won");
  const byStatus = (s: Status) => leads.filter(l => l.status === s);

  const wonLeads = leads.filter(l => l.status === "won");
  const totalActive = active.reduce((sum, a) => sum + (a.total_value ?? 0), 0);

  const Select = ({ label, value, onChange, children }: { label: string; value: string; onChange: (v: string) => void; children: React.ReactNode }) => (
    <div className="space-y-1.5">
      <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider font-mono">{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)}
        className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text h-8 px-2 text-xs rounded shadow-none outline-none appearance-none font-mono">
        {children}
      </select>
    </div>
  );

  return (
    <div className="p-4 flex flex-col gap-4 pb-24">
      <header className="mb-2 mt-4 flex justify-between items-end">
        <div>
          <h1 className="font-mono text-sm text-ikrg-text-dim uppercase tracking-widest mb-1">Outreach</h1>
          <p className="text-2xl font-mono text-ikrg-text">Sponsors</p>
        </div>
        {canWrite && (
          <Button size="sm" onClick={() => setAddOpen(true)} className="h-8 text-xs bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-text font-mono uppercase">
            <Plus className="w-3 h-3 mr-1" /> Lead
          </Button>
        )}
      </header>

      {/* Summary row */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-ikrg-card border border-ikrg-border rounded-lg p-3 text-center">
          <p className="font-mono text-[9px] text-ikrg-muted uppercase mb-1">Pipeline</p>
          <p className="font-mono text-lg font-bold text-ikrg-text">{leads.filter(l => l.status !== "lost").length}</p>
        </div>
        <div className="bg-ikrg-card border border-ikrg-border rounded-lg p-3 text-center">
          <p className="font-mono text-[9px] text-ikrg-muted uppercase mb-1">Won</p>
          <p className="font-mono text-lg font-bold text-ikrg-green">{wonLeads.length}</p>
        </div>
        <div className="bg-ikrg-card border border-ikrg-border rounded-lg p-3 text-center">
          <p className="font-mono text-[9px] text-ikrg-muted uppercase mb-1">Value</p>
          <p className="font-mono text-sm font-bold text-ikrg-green">{fmt(totalActive)}</p>
        </div>
      </div>

      <Tabs defaultValue="pipeline" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-ikrg-elevated border border-ikrg-border p-1 rounded-md h-9 mb-4">
          <TabsTrigger value="pipeline" className="data-[state=active]:bg-ikrg-card data-[state=active]:text-ikrg-text text-ikrg-muted text-[10px] font-mono rounded uppercase">Pipeline</TabsTrigger>
          <TabsTrigger value="active" className="data-[state=active]:bg-ikrg-card data-[state=active]:text-ikrg-text text-ikrg-muted text-[10px] font-mono rounded uppercase">Active Sponsors</TabsTrigger>
        </TabsList>

        <TabsContent value="pipeline" className="mt-0 outline-none space-y-3">
          {isLoading ? (
            <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse">Loading...</div>
          ) : (
            <>
              {pipeline.map(status => {
                const statusLeads = byStatus(status);
                if (statusLeads.length === 0) return null;
                return (
                  <div key={status} className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
                    <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex items-center justify-between">
                      <Badge className={`text-[9px] font-mono border ${STATUS_STYLES[status]}`}>{STATUS_LABELS[status]}</Badge>
                      <span className="font-mono text-[9px] text-ikrg-muted">{statusLeads.length}</span>
                    </div>
                    <div className="divide-y divide-ikrg-border/50">
                      {statusLeads.map(lead => (
                        <div key={lead.id} className="px-4 py-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="font-mono text-sm text-ikrg-text">{lead.company_name}</p>
                                <Badge className={`text-[9px] font-mono ${lead.category === "Sponsor" ? "bg-ikrg-amber/10 text-ikrg-amber border-ikrg-amber/30" : "bg-blue-900/20 text-blue-400 border-blue-800/30"}`}>
                                  {lead.category}
                                </Badge>
                              </div>
                              {lead.contact_name && <p className="font-mono text-[10px] text-ikrg-muted mt-0.5">{lead.contact_name}</p>}
                              {lead.poc?.name && <p className="font-mono text-[9px] text-ikrg-muted/70 mt-0.5">POC: {lead.poc.name}</p>}
                              {lead.next_followup_date && (
                                <p className="font-mono text-[9px] text-ikrg-amber mt-0.5">Follow-up: {lead.next_followup_date}</p>
                              )}
                            </div>
                            {canWrite && (
                              <button onClick={() => openEdit(lead)} className="font-mono text-[9px] text-ikrg-muted hover:text-ikrg-text uppercase flex-shrink-0">Edit →</button>
                            )}
                          </div>
                          {lead.notes && <p className="text-[11px] text-ikrg-text-dim mt-1 leading-snug line-clamp-2">{lead.notes}</p>}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
              {leads.filter(l => l.status === "lost").length > 0 && (
                <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden opacity-40">
                  <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex items-center justify-between">
                    <Badge className={`text-[9px] font-mono border ${STATUS_STYLES.lost}`}>Lost</Badge>
                    <span className="font-mono text-[9px] text-ikrg-muted">{leads.filter(l => l.status === "lost").length}</span>
                  </div>
                </div>
              )}
              {leads.length === 0 && (
                <div className="py-10 text-center font-mono text-xs text-ikrg-muted">No leads yet. Add your first lead.</div>
              )}
            </>
          )}
        </TabsContent>

        <TabsContent value="active" className="mt-0 outline-none">
          <div className="bg-ikrg-card border border-ikrg-border rounded-lg overflow-hidden">
            <div className="bg-ikrg-elevated border-b border-ikrg-border px-4 py-2 flex justify-between">
              <span className="font-mono text-[11px] text-ikrg-text-dim uppercase tracking-wider">Active Sponsors</span>
              <span className="font-mono text-[9px] text-ikrg-muted border border-ikrg-border bg-ikrg-bg px-1.5 py-0.5 rounded">{active.length}</span>
            </div>
            {isLoading ? (
              <div className="py-10 text-center font-mono text-xs text-ikrg-muted animate-pulse">Loading...</div>
            ) : active.length === 0 ? (
              <div className="py-10 text-center flex flex-col items-center gap-3">
                <Trophy className="w-8 h-8 text-ikrg-border" />
                <p className="font-mono text-xs text-ikrg-muted">No active sponsors yet.</p>
              </div>
            ) : (
              <div className="divide-y divide-ikrg-border/50">
                {active.map(s => (
                  <div key={s.id} className="px-4 py-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-mono text-sm text-ikrg-text font-semibold">{s.name}</p>
                        <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                          <Badge className={`text-[9px] font-mono border ${s.sponsorship_type === "cash" ? "text-ikrg-green border-ikrg-green/30 bg-ikrg-green/10" : s.sponsorship_type === "in_kind" ? "text-blue-400 border-blue-800/30 bg-blue-900/20" : "text-ikrg-amber border-ikrg-amber/30 bg-ikrg-amber/10"}`}>
                            {s.sponsorship_type.replace("_", " ")}
                          </Badge>
                          {s.date_received && <span className="font-mono text-[9px] text-ikrg-muted">{s.date_received}</span>}
                        </div>
                        {s.deliverables_promised && (
                          <p className="text-[10px] text-ikrg-text-dim mt-1 leading-snug">{s.deliverables_promised}</p>
                        )}
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <p className="font-mono text-sm font-bold text-ikrg-green">{fmt(s.total_value ?? 0)}</p>
                        {s.mou_url && (
                          <a href={s.mou_url} target="_blank" rel="noreferrer" className="text-[9px] text-blue-400 hover:underline font-mono flex items-center gap-0.5">
                            <ExternalLink className="w-2.5 h-2.5" /> MoU
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Add Lead Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">Add Lead</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            {[["Company *", company, setCompany, "Ex: Bosch India"], ["Contact Name", contactName, setContactName, "Ex: Rahul Sharma"], ["Contact Email", contactInfo, setContactInfo, "Email"], ["Phone", phone, setPhone, "+91..."]].map(([label, value, onChange, placeholder]) => (
              <div key={label as string} className="space-y-1.5">
                <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">{label as string}</label>
                <Input value={value as string} onChange={e => (onChange as (v: string) => void)(e.target.value)} placeholder={placeholder as string}
                  className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
              </div>
            ))}
            <div className="grid grid-cols-2 gap-2">
              <Select label="Category" value={category} onChange={v => setCategory(v as any)}>
                <option value="Sponsor">Sponsor</option>
                <option value="Vendor">Vendor</option>
              </Select>
              <Select label="Contact Method" value={contactMethod} onChange={setContactMethod}>
                <option value="email">Email</option>
                <option value="whatsapp">WhatsApp</option>
                <option value="linkedin">LinkedIn</option>
              </Select>
            </div>
            <Select label="POC (Management)" value={poc} onChange={setPoc}>
              <option value="">Unassigned</option>
              {managementMembers.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </Select>
            <div className="grid grid-cols-2 gap-2">
              {[["First Contact", firstContact, setFirstContact], ["Next Follow-up", nextFollowup, setNextFollowup]].map(([label, value, onChange]) => (
                <div key={label as string} className="space-y-1.5">
                  <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">{label as string}</label>
                  <Input type="date" value={value as string} onChange={e => (onChange as (v: string) => void)(e.target.value)}
                    className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
                </div>
              ))}
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Notes</label>
              <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Context, why are they a good fit?"
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text text-xs p-2 rounded shadow-none outline-none min-h-[60px] resize-none font-sans" />
            </div>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button disabled={!company.trim() || submitting} className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={addLead}>
              {submitting ? "Saving..." : "Add Lead"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Lead Status Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader><DialogTitle className="text-ikrg-text text-sm tracking-widest uppercase">{editLead?.company_name}</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            <Select label="Pipeline Status" value={editStatus} onChange={v => setEditStatus(v as Status)}>
              {STATUS_ORDER.map(s => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
            </Select>
            <Select label="POC (Management)" value={editPoc} onChange={setEditPoc}>
              <option value="">Unassigned</option>
              {managementMembers.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </Select>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Next Follow-up Date</label>
              <Input type="date" value={editNextFollowup} onChange={e => setEditNextFollowup(e.target.value)}
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none" />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Notes</label>
              <textarea value={editNotes} onChange={e => setEditNotes(e.target.value)}
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text text-xs p-2 rounded shadow-none outline-none min-h-[60px] resize-none font-sans" />
            </div>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button className="bg-ikrg-red text-white font-mono h-8 rounded text-xs" onClick={saveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
