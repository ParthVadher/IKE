"use client";

export const dynamic = "force-dynamic";


import { useAuth } from "@/context/AuthContext";
import { KeyHolderCard } from "@/components/KeyHolderCard";
import { SubsystemCard } from "@/components/SubsystemCard";
import { usePermission } from "@/hooks/usePermission";
import { useRole } from "@/hooks/useRole";
import { useKey } from "@/context/KeyContext";
import { useSubsystems, Subsystem } from "@/context/SubsystemContext";
import { Button } from "@/components/ui/button";
import { Plus, AlertCircle, TrendingDown } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

export default function DashboardPage() {
  const { user } = useAuth();
  const isAdmin = usePermission(3);
  const isExcomm = useRole("excomm");
  const { subsystems, addSubsystem, updateSubsystem, isLoading: isDbLoading } = useSubsystems();

  // Finance summary
  const [balances, setBalances] = useState<{ bank_balance: number; dean_balance: number; bitsaa_balance: number } | null>(null);
  const [alerts, setAlerts] = useState<{ text: string; type: "warn" | "error" }[]>([]);
  const [members, setMembers] = useState<{ id: string; name: string; username: string }[]>([]);

  useEffect(() => {
    if (!user) return;
    supabase.from("users").select("id, name, username").order("name").then(({ data }) => { if (data) setMembers(data); });
    if (isExcomm) supabase.from("account_balances").select("*").single().then(({ data }) => { if (data) setBalances(data); });
    // Build alerts from pending items
    const buildAlerts = async () => {
      const alertList: { text: string; type: "warn" | "error" }[] = [];
      const { data: overdue } = await supabase.from("reimbursements")
        .select("id").eq("status", "pending_submission").lt("date", new Date(Date.now() - 30 * 86400000).toISOString().split("T")[0]);
      if (overdue && overdue.length > 0) alertList.push({ text: `${overdue.length} reimbursement${overdue.length > 1 ? "s" : ""} pending >30 days`, type: "error" });
      const { data: pendingReq } = await supabase.from("inventory_pending").select("id").eq("approved_status", "pending");
      if (pendingReq && pendingReq.length > 0) alertList.push({ text: `${pendingReq.length} inventory request${pendingReq.length > 1 ? "s" : ""} awaiting approval`, type: "warn" });
      const { data: upcomingSubs } = await supabase.from("submissions")
        .select("id").not("status", "in", '("approved","rejected")').lte("deadline", new Date(Date.now() + 7 * 86400000).toISOString().split("T")[0]).gte("deadline", new Date().toISOString().split("T")[0]);
      if (upcomingSubs && upcomingSubs.length > 0) alertList.push({ text: `${upcomingSubs.length} submission deadline${upcomingSubs.length > 1 ? "s" : ""} within 7 days`, type: "warn" });
      setAlerts(alertList);
    };
    buildAlerts();
  }, [user, isExcomm]);

  function fmt(n: number) {
    return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
  }

  // Create Subsystem State
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newLead, setNewLead] = useState("");
  const [newLeadUsername, setNewLeadUsername] = useState("");
  const [addError, setAddError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Edit Subsystem State
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingSub, setEditingSub] = useState<Subsystem | null>(null);
  const [editName, setEditName] = useState("");
  const [editLead, setEditLead] = useState("");
  const [editTask, setEditTask] = useState("");
  const [editStatus, setEditStatus] = useState<"Active" | "Blocked">("Active");
  const [editBlockNote, setEditBlockNote] = useState("");

  if (!user) return null;

  const handleAddSubsystem = async () => {
    setAddError("");
    setIsSubmitting(true);
    try {
      await addSubsystem(newName, newLead, newLeadUsername);
      setIsAddOpen(false);
      setNewName("");
      setNewLead("");
      setNewLeadUsername("");
    } catch (e: any) {
      setAddError(e?.message || "Failed to add subsystem. Check your permissions.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditClick = (sub: Subsystem) => {
    setEditingSub(sub);
    setEditName(sub.name);
    setEditLead(sub.lead);
    setEditTask(sub.activeTask);
    setEditStatus(sub.status);
    setEditBlockNote(sub.blockNote || "");
    setIsEditOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!editingSub) return;
    await updateSubsystem(editingSub.id, {
      name: editName,
      activeTask: editTask,
      status: editStatus,
      blockNote: editStatus === "Blocked" ? editBlockNote : undefined,
    });
    setIsEditOpen(false);
  };

  return (
    <div className="p-4 flex flex-col gap-6 pb-24">
      <header className="mb-2 mt-4 flex justify-between items-end">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="Inspired Karters Logo" className="w-10 h-10 object-contain rounded-lg shadow-sm shadow-black/50" />
          <div>
            <h1 className="font-sans text-lg font-bold tracking-tight flex items-center gap-1">
              <span className="text-white">INSPIRED</span>
              <span className="text-[#d82a32]">KARTERS</span>
            </h1>
            <p className="font-mono text-xs text-ikrg-text-dim uppercase tracking-widest mt-0.5">
              Operations Terminal
            </p>
          </div>
        </div>
        <p className="font-mono text-[9px] text-ikrg-muted/40 uppercase tracking-widest">Made by Arnav Garg</p>
      </header>

      {/* Alerts */}
      {alerts.length > 0 && (
        <section className="flex flex-col gap-2">
          {alerts.map((a, i) => (
            <div key={i} className={`flex items-center gap-2 px-3 py-2 rounded border text-[10px] font-mono ${a.type === "error" ? "bg-ikrg-red/10 border-ikrg-red/30 text-ikrg-red" : "bg-ikrg-amber/10 border-ikrg-amber/30 text-ikrg-amber"}`}>
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
              {a.text}
            </div>
          ))}
        </section>
      )}

      {/* Account balances (ExComm only) */}
      {isExcomm && balances && (
        <section>
          <p className="font-mono text-[10px] text-ikrg-muted uppercase tracking-widest mb-2">Account Balances</p>
          <div className="grid grid-cols-3 gap-2">
            {([["Bank", balances.bank_balance], ["Dean", balances.dean_balance], ["BITSAA", balances.bitsaa_balance]] as [string, number][]).map(([label, val]) => (
              <div key={label} className="bg-ikrg-card border border-ikrg-border rounded-lg p-3 text-center">
                <p className="font-mono text-[9px] text-ikrg-muted uppercase tracking-widest mb-1">{label}</p>
                <p className={`font-mono text-sm font-bold ${val >= 0 ? "text-ikrg-green" : "text-ikrg-red"}`}>{fmt(val)}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      <section>
        <KeyHolderCard />
      </section>

      <section>
        <div className="flex justify-between items-end mb-4">
          <div className="flex items-center gap-3">
            <h2 className="font-mono text-sm text-ikrg-muted uppercase tracking-widest">
              Subsystems
            </h2>
            {isAdmin && (
              <Button 
                size="icon" 
                onClick={() => setIsAddOpen(true)}
                className="h-6 w-6 bg-ikrg-elevated hover:bg-ikrg-border text-ikrg-text border border-ikrg-border"
              >
                <Plus className="h-3 w-3" />
              </Button>
            )}
          </div>
          <span className="font-mono text-[10px] text-ikrg-text-dim">
            {subsystems.filter(s => s.status === 'Active').length} ACTIVE
          </span>
        </div>
        <div className="flex flex-col gap-3">
          {isDbLoading ? (
             <div className="py-10 text-center font-mono text-xs text-ikrg-muted uppercase animate-pulse">
               Connecting to Subsystems...
             </div>
          ) : (
            subsystems.map(sub => (
              <SubsystemCard 
                key={sub.id} 
                subsystem={sub} 
                onUpdate={handleEditClick}
              />
            ))
          )}
        </div>
      </section>

      {/* Add Subsystem Dialog */}
      <Dialog open={isAddOpen} onOpenChange={(o) => { setIsAddOpen(o); if (!o) setAddError(""); }}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="text-ikrg-text font-mono text-sm tracking-widest uppercase">Add Subsystem</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-2">
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Subsystem Name</label>
              <Input 
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Ex: Aerodynamics"
                className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Lead Member</label>
              <select
                value={newLeadUsername}
                onChange={(e) => {
                  const uname = e.target.value;
                  setNewLeadUsername(uname);
                  setNewLead(members.find(m => m.username === uname)?.name ?? "");
                }}
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none px-2 outline-none font-mono"
              >
                <option value="">Select a member…</option>
                {members.map(m => (
                  <option key={m.id} value={m.username}>{m.name} (@{m.username})</option>
                ))}
              </select>
            </div>
            {addError && (
              <p className="text-[10px] text-ikrg-red font-mono leading-relaxed">{addError}</p>
            )}
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setIsAddOpen(false)}>Cancel</Button>
            <Button disabled={!newName || !newLeadUsername || isSubmitting} className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-8 rounded text-xs" onClick={handleAddSubsystem}>{isSubmitting ? "Initializing…" : "Initialize"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Subsystem Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="text-ikrg-text font-mono text-sm tracking-widest uppercase">Edit Subsystem</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-2">
            {isAdmin ? (
              <>
                <div className="space-y-1.5">
                  <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Subsystem Name</label>
                  <Input 
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="bg-ikrg-bg border-ikrg-border text-ikrg-text h-8 text-xs rounded shadow-none"
                  />
                </div>
              </>
            ) : (
              <div className="p-2 border border-ikrg-border bg-ikrg-elevated rounded">
                <p className="text-[10px] text-ikrg-text-dim uppercase tracking-wider mb-1">Editing Access</p>
                <p className="text-xs text-ikrg-text">{editName} — {editLead}</p>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Current Task</label>
              <textarea 
                value={editTask}
                onChange={(e) => setEditTask(e.target.value)}
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text text-xs p-2 rounded shadow-none outline-none min-h-[60px] resize-none font-sans"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Status</label>
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant={editStatus === "Active" ? "default" : "outline"}
                  onClick={() => setEditStatus("Active")}
                  className={`flex-1 h-8 text-[10px] font-mono rounded ${editStatus === "Active" ? "bg-ikrg-green hover:bg-ikrg-green/90 text-black border-none" : "bg-transparent border-ikrg-border text-ikrg-muted"}`}
                >
                  ACTIVE
                </Button>
                <Button 
                  size="sm" 
                  variant={editStatus === "Blocked" ? "default" : "outline"}
                  onClick={() => setEditStatus("Blocked")}
                  className={`flex-1 h-8 text-[10px] font-mono rounded ${editStatus === "Blocked" ? "bg-ikrg-red hover:bg-ikrg-red/90 text-white border-none" : "bg-transparent border-ikrg-border text-ikrg-muted"}`}
                >
                  BLOCKED
                </Button>
              </div>
            </div>

            {editStatus === "Blocked" && (
              <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1">
                <label className="text-[10px] text-ikrg-amber uppercase tracking-wider">Blocker Reason</label>
                <textarea 
                  value={editBlockNote}
                  onChange={(e) => setEditBlockNote(e.target.value)}
                  placeholder="Why is it blocked?"
                  className="w-full bg-ikrg-bg border border-ikrg-amber/50 text-ikrg-amber text-xs p-2 rounded shadow-none outline-none min-h-[60px] resize-none font-sans"
                />
              </div>
            )}
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setIsEditOpen(false)}>Cancel</Button>
            <Button className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-8 rounded text-xs" onClick={handleSaveEdit}>Apply Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
