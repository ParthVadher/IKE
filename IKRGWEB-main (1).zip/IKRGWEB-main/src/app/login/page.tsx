"use client";

import { useEffect, useState, Suspense } from "react";
import { Button } from "@/components/ui/button";
import { useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";

declare global {
  interface Window { Capacitor?: { isNativePlatform: () => boolean }; }
}

function LoginContent() {
  const [error, setError] = useState("");
  const searchParams = useSearchParams();
  const errorCode = searchParams.get("error");
  const errorMessage = searchParams.get("message");

  useEffect(() => {
    if (!errorCode) return;

    console.log("LoginPage: Auth Error Detected", { errorCode, errorMessage });

    if (errorCode === "domain") {
      setError("Wrong account. Only @pilani or @alumni.bits-pilani.ac.in emails are allowed.");
    } else if (errorCode === "not_allowlisted") {
      setError("Your account exists but hasn't been granted access. Contact your admin.");
    } else if (errorCode === "exchange_failed") {
      setError(`Session handshake failed — ${errorMessage || "could not establish a secure session. Try again."}`);
    } else if (errorCode === "no_email") {
      setError("Google did not share your email address. Check your Google account permissions and retry.");
    } else if (errorCode === "unknown_state") {
      setError(`Auth callback lost the login code. Debug: ${errorMessage || "no url captured"}`);
    } else if (errorCode === "access_denied") {
      setError("You cancelled the login or denied permissions. Try again.");
    } else {
      setError(`Unexpected error [${errorCode}]: ${errorMessage || "no details"}`);
    }
  }, [errorCode, errorMessage]);

  const handleGoogleLogin = async () => {
    setError("");
    const isNative = typeof window !== 'undefined' &&
      window.Capacitor?.isNativePlatform() === true;
    const redirectTo = isNative
      ? 'ikrg://auth/native-callback'
      : `${window.location.origin}/auth/callback`;
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        queryParams: {
          prompt: 'select_account'
        },
        redirectTo,
      }
    });
  };

  return (
    <div className="flex flex-col min-h-screen p-6 pt-24 bg-ikrg-bg text-ikrg-text">
      <div className="flex-1 flex flex-col items-center justify-center -mt-20">
        <div className="text-center mb-10 w-full flex flex-col items-center">
          <img src="/logo.png" alt="Inspired Karters Logo" className="w-24 h-24 object-contain rounded-2xl mb-4 shadow-lg shadow-black/50" />
          <h1 className="font-sans text-3xl font-bold tracking-tight flex items-center gap-1.5">
            <span className="text-white">INSPIRED</span>
            <span className="text-[#d82a32]">KARTERS</span>
          </h1>
          <p className="font-mono text-xs text-ikrg-muted mt-2 uppercase tracking-wide">Terminal Access</p>
        </div>

        <div className="w-full max-w-sm space-y-4">
          <Button 
            onClick={handleGoogleLogin}
            className="w-full h-12 bg-white hover:bg-white/90 text-black font-mono uppercase tracking-wider rounded-sm flex items-center justify-center gap-3 transition-all active:scale-[0.98]"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="currentColor"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="currentColor"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
              />
              <path
                fill="currentColor"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            Sign in with BITS email
          </Button>
          
          {error && (
            <div className="bg-ikrg-red/10 border border-ikrg-red/20 p-3 rounded animate-in fade-in slide-in-from-top-1 text-center">
              <p className="text-ikrg-red text-[11px] font-mono leading-tight uppercase tracking-wider">{error}</p>
            </div>
          )}
        </div>
      </div>
      <div className="text-center pb-4 space-y-1">
        <p className="text-[10px] text-ikrg-muted font-mono uppercase tracking-widest">Identity Protocol // OAuth 2.0 // Secure</p>
        <p className="text-[10px] text-ikrg-muted/50 font-mono uppercase tracking-widest">Made by Arnav Garg</p>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-ikrg-bg text-ikrg-text flex items-center justify-center font-mono uppercase tracking-widest animate-pulse">
        Initializing Secure UI...
      </div>
    }>
      <LoginContent />
    </Suspense>
  );
}
