import { createBrowserClient } from '@supabase/ssr';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'placeholder';

const isNative = typeof window !== 'undefined' && (window as any).Capacitor?.isNativePlatform() === true;

// SSR-aware client for front-end usage (Standard Browser Client)
// This is required for PKCE flow to work correctly with cookies in Next.js.
// However, on Capacitor (Native), cookies are not reliably shared during OAuth deep-linking,
// so we fall back to the standard createClient which uses localStorage.
export const supabase = isNative
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        flowType: 'pkce',
        storage: typeof window !== 'undefined' ? window.localStorage : undefined,
        detectSessionInUrl: false,
      }
    })
  : createBrowserClient(supabaseUrl, supabaseAnonKey);

// Anon-only client for public table reads — bypasses RLS policies that
// restrict authenticated users to rows where auth_id = auth.uid().
// Safe to use for read-only lookups before auth_id is populated.
export const supabaseAnon = createClient(supabaseUrl, supabaseAnonKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

// Admin client for server-side usage (Edge Cases/API Routes)
export const createAdminClient = () => {
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceRoleKey) {
    throw new Error('Missing SUPABASE_SERVICE_ROLE_KEY');
  }
  return createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  });
};
