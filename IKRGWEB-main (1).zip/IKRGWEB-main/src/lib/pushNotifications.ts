import { PushNotifications } from "@capacitor/push-notifications";
import { supabase } from "@/lib/supabase";

const isNative = typeof window !== "undefined" &&
  (window as any).Capacitor?.isNativePlatform() === true;

let registered = false;

export async function registerPushNotifications(userId: string) {
  if (!isNative || registered) return;
  registered = true;

  // Listeners must be attached before register() — the 'registration' event can
  // fire as soon as register() resolves, and is lost if nothing is listening yet.
  PushNotifications.addListener("registration", async (token) => {
    const { error } = await supabase.from("push_tokens").upsert(
      { user_id: userId, token: token.value, platform: "android", updated_at: new Date().toISOString() },
      { onConflict: "token" }
    );
    if (error) console.error("Push token save failed", error);
  });

  PushNotifications.addListener("registrationError", (err) => {
    console.error("Push registration error", err);
    registered = false;
  });

  const perm = await PushNotifications.checkPermissions();
  if (perm.receive !== "granted") {
    const req = await PushNotifications.requestPermissions();
    if (req.receive !== "granted") { registered = false; return; }
  }

  await PushNotifications.register();
}
