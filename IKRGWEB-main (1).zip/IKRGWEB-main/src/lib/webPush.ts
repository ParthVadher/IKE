import { supabase } from "@/lib/supabase";

const VAPID_PUBLIC_KEY = "BJGUhbNKtpAOiuMKniRuBP8uVjVpNE6RSU0IuNjUU8wcPOjPDLsSfdwRE2XJlVlV_U4enI_c0nGnFEr3gzrh5EM";

const isNative = typeof window !== "undefined" &&
  (window as any).Capacitor?.isNativePlatform() === true;

let registered = false;

function urlBase64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map(c => c.charCodeAt(0)));
}

export async function registerWebPush(userId: string) {
  if (isNative || registered) return;
  if (typeof window === "undefined" || !("serviceWorker" in navigator) || !("PushManager" in window)) return;
  registered = true;

  try {
    // If this account already has a native (FCM) token registered, they have the
    // app installed — skip web push entirely so they never get double notifications.
    const { data: nativeToken } = await supabase.from("push_tokens").select("id").eq("user_id", userId).limit(1).maybeSingle();
    if (nativeToken) { registered = false; return; }

    if (Notification.permission === "default") {
      const perm = await Notification.requestPermission();
      if (perm !== "granted") { registered = false; return; }
    }
    if (Notification.permission !== "granted") { registered = false; return; }

    const reg = await navigator.serviceWorker.ready;
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });
    }

    const json = sub.toJSON();
    const { error } = await supabase.from("web_push_tokens").upsert(
      {
        user_id: userId,
        endpoint: json.endpoint,
        p256dh: json.keys?.p256dh,
        auth: json.keys?.auth,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "endpoint" }
    );
    if (error) console.error("Web push subscription save failed", error);
  } catch (err) {
    console.error("Web push registration error", err);
    registered = false;
  }
}
