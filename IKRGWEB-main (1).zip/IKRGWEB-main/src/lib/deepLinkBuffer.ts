// Registers the appUrlOpen listener at module load time — before React mounts —
// so the deep link URL is never missed due to useEffect timing.

import { App as CapacitorApp } from '@capacitor/app';

let bufferedUrl: string | null = null;
let consumer: ((url: string) => void) | null = null;

const isNative = typeof window !== 'undefined' &&
  (window as any).Capacitor?.isNativePlatform() === true;

if (isNative) {
  // Warm start: app was backgrounded; appUrlOpen fires immediately on resume
  CapacitorApp.addListener('appUrlOpen', (event) => {
    const url = event.url;
    if (consumer) {
      consumer(url);
    } else {
      bufferedUrl = url; // AuthContext not mounted yet — hold it
    }
  });

  // Cold start: app was killed; URL is available via getLaunchUrl
  CapacitorApp.getLaunchUrl().then((result) => {
    if (!result?.url) return;
    const url = result.url;
    if (consumer) {
      consumer(url);
    } else {
      bufferedUrl = url;
    }
  });
}

export function consumeDeepLink(handler: (url: string) => void): () => void {
  consumer = handler;
  if (bufferedUrl) {
    const url = bufferedUrl;
    bufferedUrl = null;
    handler(url);
  }
  return () => { consumer = null; };
}
