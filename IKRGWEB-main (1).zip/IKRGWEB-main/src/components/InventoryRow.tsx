"use client";

import { InventoryItem } from "@/app/inventory/page";
import { usePermission } from "@/hooks/usePermission";

export function InventoryRow({ item, onUpdate }: { item: InventoryItem, onUpdate?: (item: InventoryItem) => void }) {
  const canEdit = usePermission(2);

  const getBadgeStyle = (status: string) => {
    switch (status) {
      case "In Stock": return "bg-ikrg-green text-ikrg-bg";
      case "Low": return "bg-ikrg-amber text-ikrg-bg";
      case "Out of Stock": return "bg-ikrg-red text-[white]";
      default: return "bg-ikrg-muted text-[white]";
    }
  };

  const statusDot = (status: string) => {
    switch (status) {
      case "In Stock": return "bg-ikrg-green";
      case "Low": return "bg-ikrg-amber";
      case "Out of Stock": return "bg-ikrg-red";
      default: return "bg-ikrg-muted";
    }
  };

  return (
    <div className="py-3 border-b border-ikrg-border last:border-0 flex justify-between items-start gap-4 group">
      <div className="flex-1">
        <p className="font-mono text-sm mb-1">{item.name}</p>
        <p className="font-mono text-xs text-ikrg-text-dim flex items-center gap-2">
          Qty: {item.qty} units
          {item.urgency && (
             <span className={`px-1.5 py-[1px] rounded text-[9px] uppercase ${item.urgency === 'High' ? 'bg-ikrg-red text-[white]' : 'bg-ikrg-amber/20 text-ikrg-amber'}`}>
               {item.urgency} Priority
             </span>
          )}
        </p>
      </div>
      <div className="flex flex-col items-end gap-1.5 shrink-0">
        <span className="text-xs font-mono text-ikrg-text-dim">{item.status}</span>
        <div className="flex items-center gap-2">
          {canEdit && onUpdate && (
             <button onClick={() => onUpdate(item)} className="text-[10px] uppercase text-ikrg-muted hover:text-ikrg-text opacity-0 group-hover:opacity-100 transition-opacity bg-ikrg-elevated px-1.5 py-0.5 rounded">
               Update
             </button>
          )}
          <span className={`inline-block rounded-full h-2 w-2 ${statusDot(item.status)}`}></span>
        </div>
      </div>
    </div>
  );
}
