"use client";

import { useEffect, useState, useCallback } from "react";
import {
  BarcodeScanner,
  BarcodeFormat,
  LensFacing,
} from "@capacitor-mlkit/barcode-scanning";

type Props = {
  onScan: (value: string) => void;
  onClose: () => void;
};

export default function QRScanner({ onScan, onClose }: Props) {
  const [error, setError] = useState<string | null>(null);
  const [permissionDenied, setPermissionDenied] = useState(false);

  const startScan = useCallback(async () => {
    try {
      const { camera } = await BarcodeScanner.requestPermissions();
      if (camera === "denied" || camera === "prompt-with-rationale") {
        setPermissionDenied(true);
        return;
      }

      await BarcodeScanner.addListener("barcodesScanned", (event) => {
        if (event.barcodes && event.barcodes.length > 0) {
          const value = event.barcodes[0].rawValue;
          if (value) {
            BarcodeScanner.stopScan();
            BarcodeScanner.removeAllListeners();
            onScan(value);
          }
        }
      });

      await BarcodeScanner.startScan({
        formats: [BarcodeFormat.QrCode],
        lensFacing: LensFacing.Back,
      });
    } catch (e: any) {
      setError(e?.message || "Scanner failed to start");
    }
  }, [onScan]);

  useEffect(() => {
    startScan();
    return () => {
      BarcodeScanner.stopScan().catch(() => {});
      BarcodeScanner.removeAllListeners().catch(() => {});
    };
  }, [startScan]);

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center font-mono uppercase tracking-widest">
      {/* Viewfinder overlay */}
      <div className="relative w-64 h-64 mb-8">
        <div className="absolute inset-0 border-2 border-ikrg-text opacity-60 rounded" />
        {/* Corner accents */}
        <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-ikrg-text" />
        <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-ikrg-text" />
        <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-ikrg-text" />
        <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-ikrg-text" />
      </div>

      {permissionDenied ? (
        <p className="text-ikrg-red text-[11px] text-center px-8 mb-6">
          Camera permission denied. Enable it in device settings.
        </p>
      ) : error ? (
        <p className="text-ikrg-red text-[11px] text-center px-8 mb-6">{error}</p>
      ) : (
        <p className="text-ikrg-text-dim text-[11px] mb-6 animate-pulse">
          Align QR code within frame
        </p>
      )}

      <button
        onClick={() => {
          BarcodeScanner.stopScan().catch(() => {});
          BarcodeScanner.removeAllListeners().catch(() => {});
          onClose();
        }}
        className="text-ikrg-text-dim text-[11px] border border-ikrg-border px-6 py-2 rounded hover:text-ikrg-text transition-colors"
      >
        Cancel
      </button>
    </div>
  );
}
