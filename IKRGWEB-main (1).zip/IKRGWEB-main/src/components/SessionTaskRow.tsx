"use client";

import { Task } from "@/app/session/page";
import { Badge } from "./ui/badge";
import { useAuth } from "@/context/AuthContext";
import { usePermission } from "@/hooks/usePermission";

export function SessionTaskRow({ task }: { task: Task }) {
  const { user } = useAuth();
  const isAdmin = usePermission(3);
  const isMember = usePermission(2);
  const canEditTask = isAdmin || (isMember && user?.username === task.userId);

  const getStatusColor = (status: string) => {
    switch(status) {
      case "Done": return "text-ikrg-green border-ikrg-green/30 bg-ikrg-green/10";
      case "In Progress": return "text-ikrg-amber border-ikrg-amber/30 bg-ikrg-amber/10";
      case "Blocked": return "text-ikrg-red border-ikrg-red/30 bg-ikrg-red/10";
      default: return "text-ikrg-muted border-ikrg-border bg-ikrg-elevated";
    }
  };

  return (
    <div className="py-3 border-b border-ikrg-border last:border-0 group">
      <div className="flex justify-between items-start mb-2">
        <p className="text-sm flex-1 pr-4">{task.title}</p>
        <div className="flex items-center">
          {canEditTask && (
            <button className="opacity-0 group-hover:opacity-100 mr-2 text-[9px] uppercase tracking-wider text-ikrg-muted hover:text-ikrg-text bg-ikrg-elevated border border-ikrg-border px-1.5 py-0.5 rounded transition">
              Edit
            </button>
          )}
          <Badge variant="outline" className={`font-mono text-[10px] rounded-sm uppercase tracking-wider shrink-0 ${getStatusColor(task.status)}`}>
            {task.status}
          </Badge>
        </div>
      </div>
      <div className="flex gap-2 flex-wrap">
        {task.subsystemsAffected.map((sub, i) => (
          <span key={i} className="text-[10px] font-mono text-ikrg-text-dim bg-ikrg-elevated px-1.5 py-0.5 rounded border border-ikrg-border">
            {sub}
          </span>
        ))}
      </div>
    </div>
  );
}
