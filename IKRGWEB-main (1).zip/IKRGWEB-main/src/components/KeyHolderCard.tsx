"use client";

import { useKey } from "@/context/KeyContext";
import { useAuth } from "@/context/AuthContext";
import { Key, RotateCcw, ShieldAlert, Award } from "lucide-react";
import { Card } from "./ui/card";
import { usePermission } from "@/hooks/usePermission";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

export function KeyHolderCard() {
  const { keys, history, claimKey, releaseKey, reassignKey } = useKey();
  const { user } = useAuth();
  const isAdmin = usePermission(3);
  const canClaim = usePermission(2);
  
  const [isClaimDialogOpen, setIsClaimDialogOpen] = useState(false);
  const [isReassignDialogOpen, setIsReassignDialogOpen] = useState(false);
  const [selectedTarget, setSelectedTarget] = useState("");
  const [activeKeyId, setActiveKeyId] = useState<number | null>(null);

  // Fetch real users for reassignment
  const [members, setMembers] = useState<{ name: string; username: string; clearanceLevel: number }[]>([]);

  useEffect(() => {
    if (!isAdmin) return;
    const fetchMembers = async () => {
      const { data } = await supabase
        .from("users")
        .select("name, username, clearance_level")
        .gte("clearance_level", 2);
      
      if (data) {
        setMembers(data.map(u => ({
          name: u.name,
          username: u.username,
          clearanceLevel: u.clearance_level
        })));
      }
    };
    fetchMembers();
  }, [isAdmin]);

  const handleClaimClick = (keyId: number) => {
    setActiveKeyId(keyId);
    setIsClaimDialogOpen(true);
  };

  const handleReassignClick = (keyId: number) => {
    setActiveKeyId(keyId);
    setIsReassignDialogOpen(true);
  };

  const handleClaimConfirm = () => {
    if (user && activeKeyId !== null) {
      claimKey(activeKeyId, user.username);
    }
    setIsClaimDialogOpen(false);
    setActiveKeyId(null);
  };

  const handleReassignConfirm = () => {
    if (user && selectedTarget && activeKeyId !== null) {
      reassignKey(activeKeyId, user.username, selectedTarget);
    }
    setIsReassignDialogOpen(false);
    setSelectedTarget("");
    setActiveKeyId(null);
  };

  const getKeyIdFromAction = (actionText: string): number | null => {
    const match = actionText.match(/Key #(\d+)/i);
    return match ? parseInt(match[1]) : null;
  };

  return (
    <>
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between font-mono text-xs text-ikrg-text-dim px-1 mb-1">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-ikrg-muted" />
            <span className="uppercase tracking-wider font-bold">Boiler Room Key Cradle</span>
          </div>
          <span className="text-[10px] text-ikrg-muted uppercase">5 Duplicate Keys Active</span>
        </div>

        <div className="flex flex-col gap-3">
          {keys.map((key) => {
            const iHaveKey = user?.username && key.currentHolder === user.username;
            const isUnassigned = !key.currentHolder;

            // Get key-specific history
            const keyHistory = history.filter(h => {
              const kid = getKeyIdFromAction(h.rawAction);
              return kid === key.id || (kid === null && key.id === 1);
            });
            const latestLog = keyHistory[0]; // The most recent history entry for this key

            return (
              <Card 
                key={key.id} 
                className={`p-3 bg-ikrg-card border rounded-lg shadow-none relative overflow-hidden group transition-all duration-300 flex flex-col gap-3 ${
                  iHaveKey 
                    ? "border-ikrg-green/40 bg-gradient-to-r from-ikrg-card to-ikrg-green/[0.015]" 
                    : isUnassigned 
                      ? "border-ikrg-border hover:border-ikrg-amber/20" 
                      : "border-ikrg-border hover:border-ikrg-red/20"
                }`}
              >
                {/* Background Key Glow */}
                <div className={`absolute -right-4 -bottom-4 w-20 h-20 opacity-[0.03] transition-transform duration-500 group-hover:scale-110 ${
                  iHaveKey ? "text-ikrg-green" : isUnassigned ? "text-ikrg-amber" : "text-ikrg-red"
                }`}>
                  <Key className="w-full h-full" />
                </div>

                {/* Top Row: User Info & Actions */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 w-full relative z-10">
                  
                  {/* Left Side: Indicator + Key ID + Holder Details */}
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Status Indicator */}
                    <span className={`relative flex h-2.5 w-2.5 shrink-0 rounded-full ${
                      iHaveKey ? "bg-ikrg-green animate-pulse" : isUnassigned ? "bg-ikrg-amber" : "bg-ikrg-red"
                    }`}>
                      {iHaveKey && (
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-ikrg-green opacity-75"></span>
                      )}
                    </span>

                    {/* Monospace Key Label */}
                    <div className="bg-ikrg-elevated px-2 py-0.5 rounded border border-ikrg-border font-mono text-[10px] text-ikrg-muted uppercase tracking-wider font-semibold shrink-0">
                      Key #{key.id}
                    </div>

                    {/* Holder info */}
                    <div className="min-w-0 flex flex-col">
                      <span className={`font-mono text-sm tracking-tight truncate ${
                        isUnassigned 
                          ? "text-ikrg-amber/80 italic" 
                          : iHaveKey 
                            ? "text-ikrg-green font-bold" 
                            : "text-ikrg-text font-medium"
                      }`}>
                        {isUnassigned ? "Cradle Vacant" : (key.currentHolderName || key.currentHolder)}
                      </span>
                      <span className="text-[9px] font-mono text-ikrg-muted uppercase tracking-wider -mt-0.5 truncate">
                        {isUnassigned 
                          ? "Available for checkout" 
                          : iHaveKey 
                            ? "Active on your profile" 
                            : `@${key.currentHolder} holding`
                        }
                      </span>
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {isAdmin && (
                      <button 
                        onClick={() => handleReassignClick(key.id)}
                        className="text-[9px] font-mono uppercase bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border text-ikrg-muted hover:text-ikrg-text px-2 py-1.5 rounded transition-colors"
                        title="Force Reassign"
                      >
                        Override
                      </button>
                    )}

                    {canClaim && (
                      iHaveKey ? (
                        <button 
                          onClick={() => releaseKey(key.id, user.username)}
                          className="text-[9px] font-mono font-semibold uppercase tracking-wider text-ikrg-amber bg-ikrg-amber/10 border border-ikrg-amber/30 hover:bg-ikrg-amber/20 transition-all px-3 py-1.5 rounded"
                        >
                          Release
                        </button>
                      ) : (
                        <button 
                          onClick={() => handleClaimClick(key.id)}
                          className={`text-[9px] font-mono font-semibold uppercase tracking-wider transition-all px-3 py-1.5 rounded ${
                            isUnassigned
                              ? "text-white bg-ikrg-red hover:bg-ikrg-red-dim"
                              : "text-ikrg-text bg-ikrg-elevated border border-ikrg-border hover:bg-ikrg-border"
                          }`}
                        >
                          {isUnassigned ? "Claim" : "Transfer"}
                        </button>
                      )
                    )}
                  </div>
                </div>

                {/* Bottom Row: Integrated Latest Log entry */}
                <div className="w-full bg-black/20 border border-ikrg-border/50 rounded px-2.5 py-1.5 font-mono text-[9px] text-ikrg-text-dim flex items-center justify-between gap-2 relative z-10">
                  <span className="truncate">
                    {latestLog ? (
                      <span className="text-ikrg-text/80">{latestLog.rawAction}</span>
                    ) : (
                      <span className="text-ikrg-muted italic">No logged activity recorded for this key</span>
                    )}
                  </span>
                  {latestLog && (
                    <span className="text-ikrg-muted shrink-0 ml-auto">{latestLog.time}</span>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Claim Modal */}
      <Dialog open={isClaimDialogOpen} onOpenChange={setIsClaimDialogOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="font-mono text-ikrg-text flex items-center gap-2 text-sm tracking-wider uppercase">
              <Key className="w-4 h-4 text-ikrg-red animate-pulse" />
              Claim Key #{activeKeyId}
            </DialogTitle>
            <DialogDescription className="text-ikrg-text-dim text-xs mt-2 leading-relaxed">
              Are you sure? This will transfer physical control of **Boiler Room Key #{activeKeyId}** to your possession.
              {activeKeyId !== null && keys.find(k => k.id === activeKeyId)?.currentHolder && (
                <span className="block mt-2 p-2 border border-ikrg-red/20 bg-ikrg-red/5 text-ikrg-red rounded text-[10px] uppercase font-bold flex items-center gap-1.5">
                  <RotateCcw className="w-3 h-3 shrink-0" />
                  Transfers possession from @{keys.find(k => k.id === activeKeyId)?.currentHolder}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setIsClaimDialogOpen(false)}>Cancel</Button>
            <Button className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-8 rounded text-xs" onClick={handleClaimConfirm}>Yes, Claim It</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reassign Modal (Admin) */}
      <Dialog open={isReassignDialogOpen} onOpenChange={setIsReassignDialogOpen}>
        <DialogContent className="max-w-[340px] bg-ikrg-card border border-ikrg-border font-mono">
          <DialogHeader>
            <DialogTitle className="font-mono text-ikrg-text flex items-center gap-2 text-sm tracking-wider uppercase">
              <ShieldAlert className="w-4 h-4 text-ikrg-amber" />
              Admin Override: Key #{activeKeyId}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-2">
            <div className="space-y-1.5">
              <label className="text-[10px] text-ikrg-text-dim uppercase tracking-wider">Select New Holder</label>
              <select 
                value={selectedTarget}
                onChange={(e) => setSelectedTarget(e.target.value)}
                className="w-full bg-ikrg-bg border border-ikrg-border text-ikrg-text h-10 px-3 py-1 text-xs rounded shadow-none outline-none appearance-none font-mono"
              >
                <option value="" disabled>Choose member...</option>
                {members.map(t => (
                  <option key={t.username} value={t.username}>{t.name} (@{t.username})</option>
                ))}
              </select>
            </div>
          </div>
          <DialogFooter className="mt-4 flex sm:justify-start gap-2">
            <Button variant="outline" className="bg-transparent border-ikrg-border text-ikrg-text font-mono h-8 rounded text-xs" onClick={() => setIsReassignDialogOpen(false)}>Cancel</Button>
            <Button disabled={!selectedTarget} className="bg-ikrg-red hover:bg-ikrg-red-dim text-white font-mono h-8 rounded text-xs" onClick={handleReassignConfirm}>Confirm Reassign</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

