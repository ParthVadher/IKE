"use client";

import { Subsystem } from "@/context/SubsystemContext";
import { Card } from "./ui/card";
import { usePermission } from "@/hooks/usePermission";
import { useAuth } from "@/context/AuthContext";

export function SubsystemCard({ subsystem, onUpdate }: { subsystem: Subsystem; onUpdate?: (sub: Subsystem) => void }) {
  const isBlocked = subsystem.status === "Blocked";
  const { user } = useAuth();
  
  const isAdmin = usePermission(3);
  const isOwner = user?.username === subsystem.leadUsername;
  const canEdit = usePermission(2) && (isAdmin || isOwner);
  
  return (
    <Card className="p-4 bg-ikrg-card border-ikrg-border rounded-lg shadow-none relative overflow-hidden group">
      <div className="flex justify-between items-start mb-2">
        <div className="flex gap-2 items-center">
          <div className="w-6 h-6 rounded bg-ikrg-elevated flex items-center justify-center font-mono text-[10px] text-ikrg-text-dim">
            {subsystem.lead.split(" ").map((n: string) => n[0]).join("")}
          </div>
          <p className="font-mono text-sm pr-2 text-ikrg-text">{subsystem.lead}</p>
          {canEdit && onUpdate && (
             <button onClick={() => onUpdate(subsystem)} className="opacity-0 group-hover:opacity-100 text-[10px] uppercase bg-ikrg-elevated hover:bg-ikrg-border text-ikrg-muted hover:text-ikrg-text px-2 py-0.5 rounded transition-all">
               Edit
             </button>
          )}
        </div>
        <span className="relative flex h-2 w-2 mt-1">
          {isBlocked && (
             <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-ikrg-red opacity-75"></span>
          )}
          <span className={`relative inline-flex rounded-full h-2 w-2 ${isBlocked ? 'bg-ikrg-red' : 'bg-ikrg-green'}`}></span>
        </span>
      </div>
      
      <div className="flex items-center justify-between mb-3">
        <p className="text-ikrg-text-dim font-mono text-xs">{subsystem.name}</p>
        {isBlocked && (
          <span className="font-mono text-[10px] bg-ikrg-red-dim/20 text-ikrg-red px-2 py-0.5 rounded">
            — BLOCKED
          </span>
        )}
      </div>
      
      <p className="text-sm border-l-2 pl-3 border-ikrg-border text-ikrg-text leading-relaxed">
        {subsystem.activeTask}
      </p>
      
      {isBlocked && subsystem.blockNote && (
        <div className="mt-3 text-xs text-ikrg-amber font-mono bg-ikrg-amber/10 p-2 rounded">
          {subsystem.blockNote}
        </div>
      )}
    </Card>
  );
}
