"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, DollarSign, Package, Handshake, LayoutGrid } from "lucide-react";

export function BottomNav() {
  const pathname = usePathname();

  if (pathname === "/login") return null;

  const links = [
    { href: "/dashboard", icon: Home,        label: "Home"      },
    { href: "/finance",   icon: DollarSign,   label: "Finance"   },
    { href: "/inventory", icon: Package,      label: "Inventory" },
    { href: "/sponsors",  icon: Handshake,    label: "Outreach"  },
    { href: "/more",      icon: LayoutGrid,   label: "More"      },
  ];

  return (
    <div className="fixed bottom-0 w-full max-w-[390px] mx-auto border-t border-ikrg-border bg-ikrg-bg/90 backdrop-blur pb-safe pt-2 px-2 shadow-t flex justify-between items-center z-50 min-h-[64px]">
      {links.map(({ href, icon: Icon, label }) => {
        const isActive = pathname === href || (href !== "/more" && pathname.startsWith(href));
        return (
          <Link key={href} href={href} className={`flex flex-col items-center justify-center gap-1 transition-colors flex-1 ${isActive ? "text-ikrg-red" : "text-ikrg-muted hover:text-ikrg-text"}`}>
            <Icon className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-mono leading-none tracking-tight">{label}</span>
          </Link>
        );
      })}
    </div>
  );
}
