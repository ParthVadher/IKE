import { useAuth } from "@/context/AuthContext";

export type RoleId = "excomm" | "sponsorship_team" | "subsystem_lead" | "general_member" | "alumni" | "mentors";

export function useRole(...roles: RoleId[]): boolean {
  const { user } = useAuth();
  if (!user) return false;
  return roles.some(r => user.roles.includes(r));
}
