import { useAuth } from "@/context/AuthContext";

export function usePermission(minLevel: number) {
  const { user } = useAuth();
  if (!user) return false;
  return user.clearanceLevel >= minLevel;
}
