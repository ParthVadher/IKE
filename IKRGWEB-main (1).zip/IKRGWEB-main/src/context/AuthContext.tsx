"use client";

import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from "react";
import { useRouter, usePathname } from "next/navigation";
import { supabase, supabaseAnon } from "@/lib/supabase";
import { consumeDeepLink } from "@/lib/deepLinkBuffer";
import { registerPushNotifications } from "@/lib/pushNotifications";
import { registerWebPush } from "@/lib/webPush";

export type User = {
  id: string;
  auth_id: string;
  name: string;
  username: string;
  email: string;
  subsystem: string;
  clearanceLevel: number;
  roles: string[];
};

type AuthContextType = {
  user: User | null;
  logout: () => void;
  isLoading: boolean;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  logout: () => {},
  isLoading: true,
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showEmergency, setShowEmergency] = useState(false);
  const [debugInfo, setDebugInfo] = useState<string>("Initializing...");
  const isInitializing = useRef(false);
  const router = useRouter();
  const pathname = usePathname();

  // Failsafe: Show emergency options if loading takes > 6s
  useEffect(() => {
    if (!isLoading) return;
    const timer = setTimeout(() => setShowEmergency(true), 6000);
    return () => clearTimeout(timer);
  }, [isLoading]);

  // Handle identity sync from internal users table
  const syncProfile = useCallback(async (email: string, authId: string) => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      setDebugInfo(`Syncing: ${cleanEmail}...`);

      // Use anon client so RLS anon policy applies — authenticated-user RLS
      // blocks rows where auth_id = null (all users until first login sets it).
      const { data: record, error: dbErr } = await supabaseAnon
        .from("users").select("*").ilike("email", cleanEmail).single();

      if (record && !dbErr) {
        setDebugInfo(`Found: ${record.name}`);
        // Persist auth_id so future authenticated queries work
        if (!record.auth_id && authId) {
          supabase.from("users").update({ auth_id: authId }).eq("id", record.id).then(() => {});
        }
        // Load roles — authenticated client required for RLS; race a 4s timeout so
        // a stalled JWT validation on a fresh session never blocks the loading screen.
        const loadRoles = async (): Promise<string[]> => {
          const { data } = await supabase.from("user_roles").select("role_id").eq("user_id", record.id);
          return (data ?? []).map((r: any) => r.role_id);
        };
        const roles = await Promise.race([
          loadRoles(),
          new Promise<string[]>(resolve => setTimeout(() => resolve([]), 4000)),
        ]);
        setUser(prev => {
          // Never clobber already-loaded roles with an empty result — a re-fired
          // SIGNED_IN (token refresh / tab refocus) whose roles query times out
          // must not demote the user to "Access Only" out of nowhere.
          const finalRoles = roles.length > 0 ? roles : (prev && prev.id === record.id ? prev.roles : roles);
          return { id: record.id, auth_id: record.auth_id || authId, name: record.name, username: record.username, email: record.email, subsystem: record.subsystem || "—", clearanceLevel: record.clearance_level, roles: finalRoles };
        });

        // If roles came back empty, the session likely wasn't ready yet (the read
        // policy is TO authenticated). Retry in the background and patch them in so
        // ExComm-gated pages don't get stuck showing "Access Only" on a slow session.
        if (roles.length === 0) {
          (async () => {
            for (let attempt = 0; attempt < 5; attempt++) {
              await new Promise(r => setTimeout(r, 1500));
              const retry = await loadRoles();
              if (retry.length > 0) {
                setUser(prev => (prev && prev.id === record.id ? { ...prev, roles: retry } : prev));
                return;
              }
            }
          })();
        }
        return true;
      }

      setDebugInfo(`Not found: email=${cleanEmail} code=${dbErr?.code}`);
    } catch (err: any) {
      setDebugInfo(`Error: ${err.message || "Unknown"}`);
      console.error("AuthContext: Profile sync failed", err);
    }
    return false;
  }, []);

  const initSession = useCallback(async (force = false) => {
    if (isInitializing.current && !force) return;
    isInitializing.current = true;
    
    try {
      setDebugInfo("Checking session...");
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user?.email) {
        const found = await syncProfile(session.user.email, session.user.id);
        if (!found) {
          setDebugInfo("SignOut: Access Denied");
          await supabase.auth.signOut();
        }
      } else {
        setDebugInfo("No passive session");
      }
    } catch (err: any) {
      setDebugInfo(`Init Error: ${err.message}`);
    } finally {
      setIsLoading(false);
      isInitializing.current = false;
    }
  }, [syncProfile]);

  useEffect(() => {
    // Phase 1: Passive check
    initSession();

    // Phase 2: Active Listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log("AuthContext: Auth event", event);
      if (event === "SIGNED_IN" && session?.user?.email) {
        const found = await syncProfile(session.user.email, session.user.id);
        if (!found) {
          // debugInfo already set by syncProfile — don't overwrite it
          await supabase.auth.signOut();
          router.replace("/login?error=not_allowlisted");
        }
        setIsLoading(false);
      } else if (event === "SIGNED_OUT") {
        setUser(null);
        setIsLoading(false);
      }
    });

    // Phase 3: Capacitor Deep Link — registered at module load time in deepLinkBuffer.ts
    // so the URL is never missed even if appUrlOpen fires before React mounts.
    const handleDeepLink = async (url: string) => {
      if (!url.includes('auth/native-callback')) return;

      let code: string | null = null;
      let error: string | null = null;
      let hashParams: URLSearchParams | null = null;

      try {
        const parsedUrl = new URL(url);
        code = parsedUrl.searchParams.get('code');
        error = parsedUrl.searchParams.get('error');
        if (parsedUrl.hash) {
          hashParams = new URLSearchParams(parsedUrl.hash.slice(1));
        }
      } catch {
        const hashIdx = url.indexOf('#');
        const qIdx = url.indexOf('?');
        if (hashIdx !== -1) hashParams = new URLSearchParams(url.slice(hashIdx + 1));
        if (qIdx !== -1) {
          const p = new URLSearchParams(url.slice(qIdx + 1).split('#')[0]);
          code = p.get('code');
          error = p.get('error');
        }
      }

      if (error) {
        router.replace(`/login?error=${error}`);
        return;
      }

      setIsLoading(true);

      // PKCE flow: ?code=XYZ
      if (code) {
        const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
        if (exchangeError) {
          setIsLoading(false);
          router.replace(`/login?error=exchange_failed&message=${encodeURIComponent(exchangeError.message)}`);
        }
        return;
      }

      // Implicit flow fallback: #access_token=...&refresh_token=...
      const accessToken = hashParams?.get('access_token');
      const refreshToken = hashParams?.get('refresh_token');
      if (accessToken) {
        const { error: sessionError } = await supabase.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken || '',
        });
        if (sessionError) {
          setIsLoading(false);
          router.replace(`/login?error=exchange_failed&message=${encodeURIComponent(sessionError.message)}`);
        }
        return;
      }

      setIsLoading(false);
      router.replace(`/login?error=unknown_state&message=${encodeURIComponent('url:' + url)}`);
    };

    const removeDeepLinkConsumer = consumeDeepLink(handleDeepLink);

    return () => {
      subscription.unsubscribe();
      removeDeepLinkConsumer();
    };
  }, [initSession, syncProfile, router]);

  useEffect(() => {
    if (!user?.id) return;
    registerPushNotifications(user.id);
    registerWebPush(user.id);
  }, [user?.id]);

  useEffect(() => {
    if (isLoading) return;

    const isPublicRoute = pathname === "/login" || pathname.startsWith("/auth/");

    // Protect routes
    if (!user && !isPublicRoute) {
      router.push("/login");
    } else if (user && pathname === "/login") {
      router.push("/dashboard");
    }
  }, [user, isLoading, pathname, router]);

  const logout = async () => {
    try {
      const signOutPromise = supabase.auth.signOut();
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), 600));
      
      try {
        await Promise.race([signOutPromise, timeoutPromise]);
      } catch (e) {
        console.warn("AuthContext: Force redirecting.");
      }

      setUser(null);
      window.location.href = "/login";
    } catch (err) {
      window.location.href = "/login";
    }
  };

  return (
    <AuthContext.Provider value={{ user, logout, isLoading }}>
      {isLoading ? (
        <div className="min-h-screen bg-ikrg-bg text-ikrg-text flex flex-col items-center justify-center font-mono uppercase tracking-widest p-6 text-center">
          <div className="animate-pulse mb-4 italic">Initializing Hub...</div>
          <code className="text-[9px] text-ikrg-text-dim block mb-4 bg-black/40 px-2 py-1 rounded border border-ikrg-border/30">{debugInfo}</code>
          
          {showEmergency && (
            <div className="mt-8 p-4 border border-ikrg-border bg-ikrg-card rounded-lg max-w-xs animate-in fade-in zoom-in shadow-2xl">
              <div className="mb-4 text-left">
                <p className="text-[10px] text-ikrg-text-dim mb-1 leading-relaxed">
                  You are not registered as part of the team. If you think this is a mistake, contact Arnav Garg.
                </p>
                <code className="text-[9px] text-ikrg-red block truncate bg-black/40 p-1.5 rounded font-mono border border-ikrg-red/20 uppercase">
                   {debugInfo}
                </code>
              </div>
              <div className="flex flex-col gap-2">
                <button 
                  onClick={() => window.location.reload()}
                  className="w-full bg-ikrg-elevated hover:bg-ikrg-border text-ikrg-text text-[10px] py-2 rounded border border-ikrg-border transition-colors font-bold"
                >
                  Force Reconnect
                </button>
                <button 
                  onClick={() => logout()}
                  className="w-full bg-transparent hover:text-ikrg-red text-ikrg-text-dim text-[10px] py-1 transition-colors"
                >
                  Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      ) : children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
