"use client";

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "./AuthContext";

export type KeyState = {
  id: number;
  name: string;
  currentHolder: string | null;       // username
  currentHolderName: string | null;   // full name
};

export type KeyHistoryEntry = {
  id: string;
  rawAction: string;
  action: "claimed" | "released" | "reassigned";
  username: string;
  admin?: string;
  time: string;
};

type KeyContextType = {
  keys: KeyState[];
  history: KeyHistoryEntry[];
  claimKey: (keyId: number, targetUsername: string) => Promise<void>;
  releaseKey: (keyId: number, targetUsername: string) => Promise<void>;
  reassignKey: (keyId: number, adminUsername: string, targetUsername: string) => Promise<void>;
};

const KeyContext = createContext<KeyContextType>({
  keys: [],
  history: [],
  claimKey: async () => {},
  releaseKey: async () => {},
  reassignKey: async () => {},
});

export function KeyProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [keys, setKeys] = useState<KeyState[]>([]);
  const [history, setHistory] = useState<KeyHistoryEntry[]>([]);

  const fetchData = useCallback(async () => {
    // Fetch all current holders
    const { data: holderData } = await supabase
      .from("key_holder")
      .select("*, users!held_by(name, username)")
      .order("id", { ascending: true });

    if (holderData) {
      const updatedKeys = holderData.map((h: any) => ({
        id: h.id,
        name: `Boiler Room Key #${h.id}`,
        currentHolder: h.users ? h.users.username : null,
        currentHolderName: h.users ? h.users.name : null,
      }));
      setKeys(updatedKeys);
    }

    // Fetch history
    const { data: historyData } = await supabase
      .from("key_history")
      .select("*, users!performed_by(username)")
      .order("created_at", { ascending: false })
      .limit(10);

    if (historyData) {
      const formatted: KeyHistoryEntry[] = historyData.map((h: any) => ({
        id: h.id,
        rawAction: h.action,
        action: h.action.includes("reassigned") ? "reassigned" : (h.action.includes("claimed") ? "claimed" : "released"),
        username: h.users ? h.users.username : "unknown",
        admin: h.action.includes("reassigned") ? h.action.split(" ")[0] : undefined,
        time: new Date(h.created_at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })
      }));
      setHistory(formatted);
    }
  }, []);

  useEffect(() => {
    fetchData();

    const channel = supabase
      .channel("key_changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "key_holder" }, () => {
        fetchData();
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "key_history" }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchData]);

  const claimKey = async (keyId: number, username: string) => {
    if (!user) return;
    const { data: userData } = await supabase.from("users").select("id").eq("username", username).single();
    if (!userData) return;

    await supabase.from("key_holder").update({ held_by: userData.id, updated_at: new Date() }).eq("id", keyId);
    await supabase.from("key_history").insert({
      action: `${username} claimed Boiler Room Key #${keyId}`,
      performed_by: userData.id
    });
    fetchData();
  };

  const releaseKey = async (keyId: number, username: string) => {
    if (!user) return;
    const { data: userData } = await supabase.from("users").select("id").eq("username", username).single();
    if (!userData) return;

    await supabase.from("key_holder").update({ held_by: null, updated_at: new Date() }).eq("id", keyId);
    await supabase.from("key_history").insert({
      action: `${username} released Boiler Room Key #${keyId}`,
      performed_by: userData.id
    });
    fetchData();
  };

  const reassignKey = async (keyId: number, adminUsername: string, targetUsername: string) => {
    if (!user) return;
    const { data: adminData } = await supabase.from("users").select("id").eq("username", adminUsername).single();
    const { data: targetData } = await supabase.from("users").select("id").eq("username", targetUsername).single();
    if (!adminData || !targetData) return;

    await supabase.from("key_holder").update({ held_by: targetData.id, updated_at: new Date() }).eq("id", keyId);
    await supabase.from("key_history").insert({
      action: `${adminUsername} reassigned Boiler Room Key #${keyId} to ${targetUsername}`,
      performed_by: adminData.id
    });
    fetchData();
  };

  return (
    <KeyContext.Provider value={{ keys, history, claimKey, releaseKey, reassignKey }}>
      {children}
    </KeyContext.Provider>
  );
}

export function useKey() {
  return useContext(KeyContext);
}

