"use client";

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/context/AuthContext";

export type Subsystem = {
  id: string;
  name: string;
  lead: string;
  leadUsername: string;
  activeTask: string;
  status: "Active" | "Blocked";
  blockNote?: string;
};

type SubsystemContextType = {
  subsystems: Subsystem[];
  addSubsystem: (name: string, leadName: string, leadUsername: string) => Promise<void>;
  updateSubsystem: (id: string, updates: Partial<Subsystem>) => Promise<void>;
  isLoading: boolean;
};

const SubsystemContext = createContext<SubsystemContextType>({
  subsystems: [],
  addSubsystem: async () => {},
  updateSubsystem: async () => {},
  isLoading: true,
});

export function SubsystemProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [subsystems, setSubsystems] = useState<Subsystem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = useCallback(async () => {
    const { data, error } = await supabase
      .from("subsystems")
      .select("*, users!lead_user_id(name, username)");

    console.log("SubsystemContext: fetch result", { data, error });

    if (error) {
      console.error("SubsystemContext: query error", error);
      // Fallback: fetch without join
      const { data: fallback, error: fallbackError } = await supabase.from("subsystems").select("*");
      console.log("SubsystemContext: fallback result", { fallback, fallbackError });
      if (fallback && !fallbackError) {
        setSubsystems(fallback.map((s: any) => ({
          id: s.id,
          name: s.name,
          lead: "Unknown",
          leadUsername: "unknown",
          activeTask: s.current_task || "",
          status: s.is_blocked ? "Blocked" : "Active",
          blockNote: s.blocked_reason || "",
        })));
      }
    } else if (data) {
      const formatted: Subsystem[] = data.map((s: any) => ({
        id: s.id,
        name: s.name,
        lead: s.users ? s.users.name : "Unknown",
        leadUsername: s.users ? s.users.username : "unknown",
        activeTask: s.current_task || "",
        status: s.is_blocked ? "Blocked" : "Active",
        blockNote: s.blocked_reason || "",
      }));
      setSubsystems(formatted);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (!user) return;
    fetchData();

    const channel = supabase
      .channel("subsystem_changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "subsystems" }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchData, user]);

  const addSubsystem = async (name: string, leadName: string, leadUsername: string) => {
    // Resolve the lead's internal id from their username. maybeSingle() returns
    // null (instead of throwing) when there's no match, so we can give a clear error.
    const { data: userData, error: lookupErr } = await supabase
      .from("users").select("id").eq("username", leadUsername).maybeSingle();
    if (lookupErr) throw new Error(lookupErr.message);
    if (!userData) throw new Error(`No member found with username "${leadUsername}"`);

    const { error: insertErr } = await supabase.from("subsystems").insert({
      name,
      lead_user_id: userData.id,
      current_task: "System initialized.",
      is_blocked: false
    });
    if (insertErr) throw new Error(insertErr.message);

    await fetchData();
  };

  const updateSubsystem = async (id: string, updates: Partial<Subsystem>) => {
    const mappedUpdates: any = {};
    if (updates.name !== undefined) mappedUpdates.name = updates.name;
    if (updates.activeTask !== undefined) mappedUpdates.current_task = updates.activeTask;
    if (updates.status !== undefined) mappedUpdates.is_blocked = updates.status === "Blocked";
    if (updates.blockNote !== undefined) mappedUpdates.blocked_reason = updates.blockNote;
    
    // If leadUsername changed, we'd need to lookup user ID
    if (updates.leadUsername) {
       const { data: userData } = await supabase.from("users").select("id").eq("username", updates.leadUsername).single();
       if (userData) mappedUpdates.lead_user_id = userData.id;
    }

    await supabase.from("subsystems").update(mappedUpdates).eq("id", id);
  };

  return (
    <SubsystemContext.Provider value={{ subsystems, addSubsystem, updateSubsystem, isLoading }}>
      {children}
    </SubsystemContext.Provider>
  );
}

export function useSubsystems() {
  return useContext(SubsystemContext);
}
